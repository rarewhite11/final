Ресурсы оригинальной Plants vs. Zombies интегрированы в папку assets/.

Проверка ресурсов:
  python tests/validate_project.py --repeat 100 --http

Диагностическая страница Reanim:
  http://127.0.0.1:8001/reanim-full-smoke.html

Обычный запуск:
  start_game.bat

Исходная база pvz.sqlite3 сохранена.
