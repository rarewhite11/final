В ЭТОЙ ПАПКЕ ДОЛЖНЫ ЛЕЖАТЬ ИЗОБРАЖЕНИЯ ИЗ ТВОЕГО ИСХОДНОГО ПРОЕКТА:
pea-shooter.png, sunflower.png, walnut.png, ice-shooter.png, spikerock.png,
zombie-normal.png, zombie-bucket.png, All-Star Zombie.png, zomboni.png,
pea.png, ice-pea.png, sun.png, sun-gold.png, sun-blue.png, pvz-bg.jpg.

Эти изображения не были среди загруженных в чат файлов. Скопируй сюда папку images из своего исходного проекта, чтобы увидеть оригинальные модели и фон. Код игры содержит простые запасные отрисовки для части игровых объектов, но меню использует эти изображения.
