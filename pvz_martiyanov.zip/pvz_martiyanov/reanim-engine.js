/*
 * PVZ Reanim Runtime
 * Original PopCap Reanim timelines + original layered PNG resources.
 * Offline-only. Visual layers are detected by their image symbol, not by
 * their name: original files contain visual tracks named "anim_bucket",
 * "anim_cone", "anim_head1", etc.
 */
(() => {
  'use strict';

  const ROOT = '/assets/reanim/';
  const MAP_URL = '/assets/reanim-image-map.json';
  const definitions = new Map();
  const loadingDefinitions = new Map();
  const imagePromises = new Map();
  const loadedImages = new Map();
  const missingTextures = new Set();
  const boundsCache = new Map();

  const aliases = {
    PeaShooter: { idle: ['anim_full_idle'], shoot: ['anim_shooting'] },
    PeaShooterSingle: { idle: ['anim_full_idle'], shoot: ['anim_shooting'] },
    Tallnut: { idle: ['anim_idle'], blink: ['anim_blink_twice', 'anim_blink_thrice'] },
    Jalapeno: { idle: ['anim_idle'], explode: ['anim_explode'] },
    SunFlower: { idle: ['anim_idle'], blink: ['anim_blink'] },
    SnowPea: { idle: ['anim_full_idle'], shoot: ['anim_shooting'] },
    Wallnut: { idle: ['anim_idle'], blink: ['anim_blink_twitch'], blinkTwice: ['anim_blink_twice'], blinkThrice: ['anim_blink_thrice'] },
    Caltrop: { idle: ['anim_idle'], attack: ['anim_attack'], blink: ['anim_blink'] },
    PotatoMine: { idle: ['anim_idle'], armed: ['anim_armed'] },
    Zombie: { walk: ['anim_walk', 'anim_walk2'], eat: ['anim_eat'], death: ['anim_death'], idle: ['anim_idle2'] },
    Zombie_football: { walk: ['anim_walk'], eat: ['anim_eat'], death: ['anim_death'] },
    Zombie_zamboni: { walk: ['anim_drive'], drive: ['anim_drive'], wheelie: ['anim_wheelie1', 'anim_wheelie2'] },
    Zombie_polevaulter: { walk: ['anim_walk'], run: ['anim_run'], jump: ['anim_jump'], eat: ['anim_eat'], death: ['anim_death'] },
    Zombie_balloon: { walk: ['anim_walk'], eat: ['anim_eat'], death: ['anim_death'], pop: ['anim_pop'] },
    Zombie_dancer: { walk: ['anim_walk'], eat: ['anim_eat'], death: ['anim_death'], dance: ['anim_armraise'] },
    Zombie_jackbox: { walk: ['anim_walk'], idle: ['anim_idle'], eat: ['anim_eat'], pop: ['anim_pop'], death: ['anim_death'] },
    Zombie_backup: { walk: ['anim_walk'], eat: ['anim_eat'], death: ['anim_death'], dance: ['anim_armraise'] },
    Zombie_gargantuar: { walk: ['anim_walk'], eat: ['anim_smash'], smash: ['anim_smash'], throw: ['anim_throw'], death: ['anim_death'] },
    Zombie_imp: { walk: ['anim_walk'], eat: ['anim_eat'], thrown: ['anim_thrown'], land: ['anim_land'], death: ['anim_death'] },
    Cactus: { idle: ['anim_idle'], shoot: ['anim_shooting'], rise: ['anim_rise'], idleHigh: ['anim_idlehigh'], shootHigh: ['anim_shootinghigh'], lower: ['anim_lower'] },
    Squash: { idle: ['anim_idle'], attack: ['anim_jumpdown'], jump: ['anim_jumpup'] },
    Sun: { idle: ['anim_idle'] }
  };

  let imageMapPromise = null;
  function getImageMap() {
    if (!imageMapPromise) {
      imageMapPromise = fetch(MAP_URL).then(response => {
        if (!response.ok) throw new Error(`Не удалось загрузить карту текстур: ${response.status}`);
        return response.json();
      });
    }
    return imageMapPromise;
  }

  function parseReanim(source, name) {
    const xml = new DOMParser().parseFromString(`<reanimRoot>${source}</reanimRoot>`, 'application/xml');
    if (xml.querySelector('parsererror')) throw new Error(`Повреждён файл анимации ${name}.reanim`);

    const fps = Math.max(1, Number(xml.querySelector('fps')?.textContent) || 12);
    const tracks = [];
    let totalFrames = 1;

    for (const node of Array.from(xml.documentElement.children).filter(child => child.tagName === 'track')) {
      const trackName = node.querySelector(':scope > name')?.textContent?.trim();
      if (!trackName) continue;
      const frames = Array.from(node.children).filter(child => child.tagName === 't').map(frameNode => {
        const values = {};
        for (const child of Array.from(frameNode.children)) {
          const key = child.tagName;
          const raw = child.textContent.trim();
          values[key] = key === 'i' ? raw : Number(raw);
        }
        return values;
      });
      totalFrames = Math.max(totalFrames, frames.length);
      // Reanim has image-bearing layers whose names also start with "anim_".
      // Only marker-only anim_* tracks are control tracks.
      const isVisual = frames.some(frame => typeof frame.i === 'string' && frame.i.length > 0);
      tracks.push({ name: trackName, frames, isVisual, isControl: !isVisual && trackName.startsWith('anim_') });
    }

    // A few original clip markers (notably SunFlower's anim_idle/anim_blink)
    // are image-bearing tracks themselves, so keep every anim_* track here.
    const controlTracks = new Map(tracks.filter(track => track.name.startsWith('anim_')).map(track => [track.name, track]));
    return { name, fps, totalFrames, tracks: tracks.filter(track => track.isVisual), controlTracks, imageMap: {} };
  }

  async function loadImage(url) {
    if (loadedImages.has(url)) return loadedImages.get(url);
    if (!imagePromises.has(url)) {
      const promise = new Promise((resolve, reject) => {
        const image = new Image();
        image.decoding = 'async';
        image.onload = () => resolve(image);
        image.onerror = () => reject(new Error(`Не удалось загрузить текстуру: ${url}`));
        // Resolve every Reanim texture from the local project root.
        image.src = new URL(url.replace(/^\//, ''), `${window.location.origin}/`).href;
      });
      imagePromises.set(url, promise);
    }
    try {
      const image = await imagePromises.get(url);
      loadedImages.set(url, image);
      return image;
    } catch (error) {
      missingTextures.add(url);
      throw error;
    }
  }

  async function load(name) {
    if (definitions.has(name)) return definitions.get(name);
    if (loadingDefinitions.has(name)) return loadingDefinitions.get(name);

    const task = (async () => {
      const response = await fetch(`${ROOT}${encodeURIComponent(name)}.reanim`, { cache: 'no-cache' });
      if (!response.ok) throw new Error(`Не найден ${name}.reanim (${response.status})`);
      const definition = parseReanim(await response.text(), name);
      definition.imageMap = await getImageMap();

      const symbols = new Set();
      for (const track of definition.tracks) {
        for (const frame of track.frames) if (frame.i) symbols.add(frame.i);
      }

      const jobs = [];
      for (const symbol of symbols) {
        const url = definition.imageMap[symbol];
        if (!url) {
          missingTextures.add(symbol);
          console.warn(`[Reanim] В карте нет текстуры для ${symbol}`);
          continue;
        }
        jobs.push(loadImage(url).catch(error => console.warn(`[Reanim] ${error.message}`)));
      }
      await Promise.all(jobs);
      definitions.set(name, definition);
      return definition;
    })();

    loadingDefinitions.set(name, task);
    try {
      return await task;
    } catch (error) {
      console.error(`[Reanim] ${name}:`, error);
      return null;
    } finally {
      loadingDefinitions.delete(name);
    }
  }

  function activeRanges(controlTrack) {
    if (!controlTrack) return [];
    const markers = [];
    controlTrack.frames.forEach((frame, index) => {
      if (Object.prototype.hasOwnProperty.call(frame, 'f')) markers.push({ frame: index, value: frame.f });
    });
    if (!markers.length) return [];

    const ranges = [];
    let start = null;
    for (const marker of markers) {
      if (marker.value >= 0 && start === null) {
        start = marker.frame;
      } else if (marker.value < 0 && start !== null) {
        if (marker.frame > start) ranges.push({ start, end: marker.frame });
        start = null;
      }
    }
    if (start !== null) ranges.push({ start, end: controlTrack.frames.length });

    // A few original clips contain only an end marker, meaning frame zero is
    // their implicit start (Wall-nut idle and Zomboni drive are examples).
    if (!ranges.length && !markers.some(marker => marker.value >= 0)) {
      const endMarker = markers.find(marker => marker.value < 0 && marker.frame > 0);
      if (endMarker) ranges.push({ start: 0, end: endMarker.frame });
    }
    return ranges;
  }

  function resolveRange(definition, clip) {
    const names = aliases[definition.name]?.[clip] || [`anim_${clip}`];
    // Aliases are ordered fallbacks, not clips to merge. Merging separate
    // timelines (e.g. Zombie walk and walk2) plays unrelated frames together.
    for (const name of names) {
      const ranges = activeRanges(definition.controlTracks.get(name));
      if (ranges.length) return ranges[0];
    }
    return { start: 0, end: definition.totalFrames };
  }

  function interpolateAngle(from, to, amount) {
    const delta = ((to - from + 540) % 360) - 180;
    return from + delta * amount;
  }

  function propertyAt(frames, frame, key, fallback, interpolate) {
    let previousIndex = -1;
    let previousValue;
    let nextIndex = -1;
    let nextValue;
    for (let index = 0; index < frames.length; index++) {
      if (!Object.prototype.hasOwnProperty.call(frames[index], key)) continue;
      if (index <= frame) {
        previousIndex = index;
        previousValue = frames[index][key];
      } else {
        nextIndex = index;
        nextValue = frames[index][key];
        break;
      }
    }
    if (previousIndex < 0) return fallback;
    if (interpolate && nextIndex > previousIndex && typeof previousValue === 'number' && typeof nextValue === 'number') {
      const ratio = Math.max(0, Math.min(1, (frame - previousIndex) / (nextIndex - previousIndex)));
      if (key === 'kx' || key === 'ky') return interpolateAngle(previousValue, nextValue, ratio);
      return previousValue + (nextValue - previousValue) * ratio;
    }
    return previousValue;
  }

  function trackIsHidden(track, options) {
    return (options.hiddenTracks || []).includes(track.name);
  }
  function trackIsIncluded(track, options) {
    return !options.includeTracks || options.includeTracks.includes(track.name);
  }
  function trackIsForced(track, options) {
    return (options.forceVisibleTracks || []).includes(track.name);
  }

  function clipBounds(definition, clip, options = {}) {
    const cacheKey = `${definition.name}:${clip || 'idle'}:${(options.hiddenTracks || []).join(',')}:${(options.includeTracks || []).join(',')}:${(options.forceVisibleTracks || []).join(',')}`;
    if (boundsCache.has(cacheKey)) return boundsCache.get(cacheKey);

    const range = resolveRange(definition, clip || 'idle');
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const track of definition.tracks) {
      if (trackIsHidden(track, options) || !trackIsIncluded(track, options)) continue;
      for (let frame = range.start; frame < range.end; frame++) {
        const symbol = propertyAt(track.frames, frame, 'i', null, false);
        if (!symbol) continue;
        const forced = trackIsForced(track, options);
        if (!forced && propertyAt(track.frames, frame, 'f', 0, false) < 0) continue;
        const url = definition.imageMap[symbol];
        const image = url && loadedImages.get(url);
        if (!image) continue;

        const px = propertyAt(track.frames, frame, 'x', 0, true);
        const py = propertyAt(track.frames, frame, 'y', 0, true);
        const sx = propertyAt(track.frames, frame, 'sx', 1, true);
        const sy = propertyAt(track.frames, frame, 'sy', 1, true);
        const kx = ((propertyAt(track.frames, frame, 'kx', 0, true) % 360) * Math.PI) / 180;
        const ky = ((propertyAt(track.frames, frame, 'ky', 0, true) % 360) * Math.PI) / 180;
        const a = Math.cos(kx) * sx, b = Math.sin(kx) * sx;
        const c = -Math.sin(ky) * sy, d = Math.cos(ky) * sy;
        // Original Reanim x/y are the image's top-left anchor. Keeping that
        // origin is essential: the individual limbs/body layers are authored
        // to meet at these coordinates. Centering every PNG breaks the rig.
        const imageW = image.naturalWidth;
        const imageH = image.naturalHeight;
        for (const [cx, cy] of [[0, 0], [imageW, 0], [imageW, imageH], [0, imageH]]) {
          const tx = px + a * cx + c * cy;
          const ty = py + b * cx + d * cy;
          minX = Math.min(minX, tx); minY = Math.min(minY, ty);
          maxX = Math.max(maxX, tx); maxY = Math.max(maxY, ty);
        }
      }
    }

    const bounds = Number.isFinite(minX)
      ? { minX, minY, maxX, maxY }
      : { minX: 0, minY: 0, maxX: 100, maxY: 100 };
    boundsCache.set(cacheKey, bounds);
    return bounds;
  }

  function draw(ctx, name, clip, x, y, scale = 1, seconds = 0, options = {}) {
    const definition = definitions.get(name);
    if (!definition) return false;

    const range = resolveRange(definition, clip || 'idle');
    const bounds = clipBounds(definition, clip || 'idle', options);
    if (options.align === 'center') {
      x -= ((bounds.minX + bounds.maxX) / 2) * scale;
      y -= ((bounds.minY + bounds.maxY) / 2) * scale;
    } else if (options.align === 'topleft') {
      x -= bounds.minX * scale;
      y -= bounds.minY * scale;
    }

    const length = Math.max(1, range.end - range.start);
    const safeSeconds = Number.isFinite(seconds) ? Math.max(0, seconds) : 0;
    const rawFrame = safeSeconds * definition.fps;
    const frame = options.loop === false
      ? Math.min(range.end - 1, range.start + rawFrame)
      : range.start + (rawFrame % length);

    let drawn = 0;
    ctx.save();
    if (Number.isFinite(options.alpha)) ctx.globalAlpha *= Math.max(0, Math.min(1, options.alpha));
    ctx.translate(x, y);
    ctx.scale(scale, scale);
    for (const track of definition.tracks) {
      if (trackIsHidden(track, options) || !trackIsIncluded(track, options)) continue;
      const symbol = propertyAt(track.frames, frame, 'i', null, false);
      if (!symbol) continue;
      const forced = trackIsForced(track, options);
      if (!forced && propertyAt(track.frames, frame, 'f', 0, false) < 0) continue;

      const url = definition.imageMap[symbol];
      const image = url && loadedImages.get(url);
      if (!image) continue;

      const px = propertyAt(track.frames, frame, 'x', 0, true);
      const py = propertyAt(track.frames, frame, 'y', 0, true);
      const sx = propertyAt(track.frames, frame, 'sx', 1, true);
      const sy = propertyAt(track.frames, frame, 'sy', 1, true);
      const kx = ((propertyAt(track.frames, frame, 'kx', 0, true) % 360) * Math.PI) / 180;
      const ky = ((propertyAt(track.frames, frame, 'ky', 0, true) % 360) * Math.PI) / 180;
      const a = Math.cos(kx) * sx, b = Math.sin(kx) * sx;
      const c = -Math.sin(ky) * sy, d = Math.cos(ky) * sy;
      ctx.save();
      ctx.transform(a, b, c, d, px, py);
      ctx.drawImage(image, 0, 0);
      ctx.restore();
      drawn++;
    }
    ctx.restore();
    return drawn > 0;
  }

  async function preload(names) {
    return Promise.all(names.map(load));
  }

  function duration(name, clip) {
    const definition = definitions.get(name);
    if (!definition) return 0;
    const range = resolveRange(definition, clip || 'idle');
    return Math.max(1, range.end - range.start) / definition.fps;
  }

  function status() {
    return {
      loadedAnimations: Array.from(definitions.keys()),
      loadedTextures: loadedImages.size,
      missingTextures: Array.from(missingTextures)
    };
  }

  window.PVZReanim = {
    load,
    preload,
    draw,
    duration,
    status,
    bounds: (name, clip, options) => {
      const definition = definitions.get(name);
      return definition ? clipBounds(definition, clip, options || {}) : null;
    }
  };
})();
