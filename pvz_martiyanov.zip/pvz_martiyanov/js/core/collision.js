
/**
 * Общие функции геометрии и столкновений.
 *
 * Все прямоугольники задаются через x, y, width, height.
 * Координаты должны относиться к одной системе игрового поля.
 */

/**
 * Проверяет пересечение двух прямоугольников.
 */
export function intersectsRect(a, b) {
    if (!a || !b) {
        return false;
    }

    const ax = a.x;
    const ay = a.y;
    const aw = a.width;
    const ah = a.height;

    const bx = b.x;
    const by = b.y;
    const bw = b.width;
    const bh = b.height;

    if (
        ![ax, ay, aw, ah, bx, by, bw, bh].every(Number.isFinite) ||
        aw < 0 ||
        ah < 0 ||
        bw < 0 ||
        bh < 0
    ) {
        return false;
    }

    return (
        ax < bx + bw &&
        ax + aw > bx &&
        ay < by + bh &&
        ay + ah > by
    );
}

/**
 * Проверяет, находится ли точка внутри прямоугольника.
 */
export function pointInRect(pointX, pointY, rect) {
    if (
        !rect ||
        !Number.isFinite(pointX) ||
        !Number.isFinite(pointY) ||
        !Number.isFinite(rect.x) ||
        !Number.isFinite(rect.y) ||
        !Number.isFinite(rect.width) ||
        !Number.isFinite(rect.height)
    ) {
        return false;
    }

    return (
        pointX >= rect.x &&
        pointX <= rect.x + rect.width &&
        pointY >= rect.y &&
        pointY <= rect.y + rect.height
    );
}

/**
 * Проверяет, находится ли точка внутри окружности.
 */
export function pointInCircle(
    pointX,
    pointY,
    circleX,
    circleY,
    radius
) {
    if (
        ![
            pointX,
            pointY,
            circleX,
            circleY,
            radius,
        ].every(Number.isFinite) ||
        radius < 0
    ) {
        return false;
    }

    const dx = pointX - circleX;
    const dy = pointY - circleY;

    return dx * dx + dy * dy <= radius * radius;
}

/**
 * Проверяет пересечение двух окружностей.
 */
export function intersectsCircle(a, b) {
    if (!a || !b) {
        return false;
    }

    if (
        ![
            a.x,
            a.y,
            a.radius,
            b.x,
            b.y,
            b.radius,
        ].every(Number.isFinite) ||
        a.radius < 0 ||
        b.radius < 0
    ) {
        return false;
    }

    const dx = a.x - b.x;
    const dy = a.y - b.y;
    const radiusSum = a.radius + b.radius;

    return dx * dx + dy * dy <= radiusSum * radiusSum;
}

/**
 * Проверяет пересечение окружности с прямоугольником.
 */
export function intersectsRectCircle(rect, circle) {
    if (!rect || !circle) {
        return false;
    }

    if (
        ![
            rect.x,
            rect.y,
            rect.width,
            rect.height,
            circle.x,
            circle.y,
            circle.radius,
        ].every(Number.isFinite) ||
        rect.width < 0 ||
        rect.height < 0 ||
        circle.radius < 0
    ) {
        return false;
    }

    const closestX = Math.max(
        rect.x,
        Math.min(circle.x, rect.x + rect.width)
    );

    const closestY = Math.max(
        rect.y,
        Math.min(circle.y, rect.y + rect.height)
    );

    const dx = circle.x - closestX;
    const dy = circle.y - closestY;

    return dx * dx + dy * dy <= circle.radius * circle.radius;
}

/**
 * Проверяет, находится ли прямоугольник внутри границ.
 */
export function isInsideBounds(
    rect,
    boundsWidth,
    boundsHeight
) {
    if (
        !rect ||
        ![
            rect.x,
            rect.y,
            rect.width,
            rect.height,
            boundsWidth,
            boundsHeight,
        ].every(Number.isFinite) ||
        rect.width < 0 ||
        rect.height < 0 ||
        boundsWidth < 0 ||
        boundsHeight < 0
    ) {
        return false;
    }

    return (
        rect.x >= 0 &&
        rect.y >= 0 &&
        rect.x + rect.width <= boundsWidth &&
        rect.y + rect.height <= boundsHeight
    );
}

/**
 * Ограничивает координаты прямоугольника игровым полем.
 */
export function clampRectToBounds(
    rect,
    boundsWidth,
    boundsHeight
) {
    if (
        !rect ||
        ![
            rect.x,
            rect.y,
            rect.width,
            rect.height,
            boundsWidth,
            boundsHeight,
        ].every(Number.isFinite) ||
        rect.width < 0 ||
        rect.height < 0 ||
        boundsWidth < 0 ||
        boundsHeight < 0
    ) {
        return null;
    }

    const width = Math.min(rect.width, boundsWidth);
    const height = Math.min(rect.height, boundsHeight);

    const x = Math.max(
        0,
        Math.min(rect.x, boundsWidth - width)
    );

    const y = Math.max(
        0,
        Math.min(rect.y, boundsHeight - height)
    );

    return {
        ...rect,
        x,
        y,
        width,
        height,
    };
}

/**
 * Проверяет пересечение снаряда с зомби.
 *
 * Функция ожидает, что у снаряда есть радиус,
 * а у зомби — прямоугольные размеры.
 */
export function projectileIntersectsZombie(projectile, zombie) {
    if (!projectile || !zombie) {
        return false;
    }

    const radius = Number.isFinite(projectile.radius)
        ? projectile.radius
        : 10;

    return intersectsRectCircle(
        {
            x: zombie.x,
            y: zombie.y,
            width: zombie.width,
            height: zombie.height,
        },
        {
            x: projectile.x,
            y: projectile.y,
            radius,
        }
    );
}
