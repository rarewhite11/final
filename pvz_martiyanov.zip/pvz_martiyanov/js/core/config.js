/**
 * Plants vs. Zombies
 * Центральная конфигурация игры.
 *
 * Пока старый script.js продолжает работать отдельно.
 * Подключим эту конфигурацию при переносе игровой логики.
 */

export const GAME_CONFIG = {
    // Размер поля — соответствует исходному script.js
    COLS: 8,
    ROWS: 5,
    CELL_W: 113,
    CELL_H: 120,

    // Начальные ресурсы
    STARTING_SUN: 150,
    SUN_FALL_INTERVAL: 20000,
    SUN_VISUAL_SIZE: 40,
    SUN_HITBOX_SIZE: 60,

    // Игровой цикл
    TARGET_FPS: 60,
    MAX_DELTA_TIME: 0.05,

    // Волны
    MAX_WAVES: 100,
    FIRST_WAVE: 1,
    ZOMBIE_SPAWN_DELAY: 5000,
    WAVE_MESSAGE_DURATION: 90,
    NEXT_WAVE_DELAY: 300,

    // Анимации
    ANIMATION_SPEED: 8,
};

export const PLANT_CONFIG = {
    pea: {
        name: "Горохострел",
        cost: 100,
        health: 300,
        damage: 20,
        attackInterval: 1.5,
        cooldown: 5,
    },

    sunflower: {
        name: "Подсолнух",
        cost: 50,
        health: 300,
        sunValue: 25,
        sunInterval: 24,
        cooldown: 3,
    },

    walnut: {
        name: "Орех",
        cost: 50,
        health: 4000,
        cooldown: 30,
    },

    iceshooter: {
        name: "Ледострел",
        cost: 150,
        health: 300,
        damage: 20,
        attackInterval: 1.5,
        slowMultiplier: 0.5,
        slowDuration: 3,
        cooldown: 7,
    },

    spikerock: {
        name: "Колючка",
        cost: 125,
        health: Infinity,
        damage: 20,
        cooldown: 8,
    },
};

export const ZOMBIE_CONFIG = {
    normal: {
        name: "Обычный зомби",
        health: 200,
        speed: 0.17,
        damagePerSecond: 100,
        score: 10,
        minWave: 1,
    },

    bucket: {
        name: "Ведёрный зомби",
        health: 1100,
        speed: 0.17,
        damagePerSecond: 100,
        score: 20,
        minWave: 5,
    },

    allstar: {
        name: "All-Star Zombie",
        health: 1800,
        speed: 0.24,
        damagePerSecond: 100,
        score: 30,
        minWave: 10,
    },

    zomboni: {
        name: "Зомбони",
        health: 1350,
        speed: 0.16,
        damagePerSecond: 999,
        score: 50,
        minWave: 20,
        explosionRadius: 1,
        explosionDamage: 40,
    },
};

export const BALANCE_CONFIG = {
    // Урон и здоровье
    plantDamageMultiplier: 1,
    zombieHealthMultiplier: 1,

    // Ранняя игра
    earlyWaveLimit: 5,
    earlyWaveSpecialZombieChance: 0,

    // Рост сложности
    baseZombiesPerWave: 3,
    additionalZombiesPerWave: 1,

    // Ограничение времени одного кадра
    minDeltaTime: 0,
    maxDeltaTime: 0.05,
};