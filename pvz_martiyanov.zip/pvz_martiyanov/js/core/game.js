
import { GAME_CONFIG } from "./config.js";

/**
 * Центральное состояние модульной версии игры.
 *
 * Пока не подключено к старому script.js.
 * Не заменяет существующий игровой цикл и отрисовку.
 */

export function createGameState() {
    return {
        running: false,
        active: false,
        paused: false,
        gameOver: false,

        sun: GAME_CONFIG.STARTING_SUN,
        score: 0,
        kills: 0,

        currentWave: 1,
        totalWaves: GAME_CONFIG.MAX_WAVES,

        plants: [],
        zombies: [],
        projectiles: [],
        suns: [],
        iceTrails: [],

        startedAt: null,
        lastFrameAt: null,

        reset() {
            this.running = false;
            this.active = false;
            this.paused = false;
            this.gameOver = false;

            this.sun = GAME_CONFIG.STARTING_SUN;
            this.score = 0;
            this.kills = 0;

            this.currentWave = 1;

            this.plants.length = 0;
            this.zombies.length = 0;
            this.projectiles.length = 0;
            this.suns.length = 0;
            this.iceTrails.length = 0;

            this.startedAt = null;
            this.lastFrameAt = null;
        },

        start() {
            if (this.gameOver) {
                return false;
            }

            this.running = true;
            this.active = true;
            this.paused = false;

            const now = Date.now();

            if (this.startedAt === null) {
                this.startedAt = now;
            }

            this.lastFrameAt = now;
            return true;
        },

        pause() {
            if (!this.running || this.gameOver) {
                return false;
            }

            this.paused = true;
            return true;
        },

        resume() {
            if (!this.running || this.gameOver) {
                return false;
            }

            this.paused = false;
            this.lastFrameAt = Date.now();
            return true;
        },

        togglePause() {
            if (!this.running || this.gameOver) {
                return false;
            }

            this.paused = !this.paused;
            this.lastFrameAt = Date.now();

            return this.paused;
        },

        addSun(amount) {
            if (!Number.isFinite(amount) || amount <= 0) {
                return false;
            }

            this.sun += amount;
            return true;
        },

        spendSun(amount) {
            if (!Number.isFinite(amount) || amount < 0) {
                return false;
            }

            if (this.sun < amount) {
                return false;
            }

            this.sun -= amount;
            return true;
        },

        addScore(amount) {
            if (!Number.isFinite(amount) || amount <= 0) {
                return false;
            }

            this.score += amount;
            return true;
        },

        registerKill(zombie) {
            this.kills += 1;

            const points = Number.isFinite(zombie?.score)
                ? zombie.score
                : 10;

            this.score += points;
        },

        setWave(wave) {
            if (!Number.isInteger(wave) || wave < 1) {
                return false;
            }

            this.currentWave = wave;
            return true;
        },

        end() {
            this.running = false;
            this.active = false;
            this.paused = false;
            this.gameOver = true;
        },
    };
}

/**
 * Экземпляр состояния для модулей,
 * которым нужен общий игровой объект.
 */
export const gameState = createGameState();
