
import { GAME_CONFIG } from "../core/config.js";

/**
 * Создаёт солнце.
 *
 * x, y — координаты.
 * value — количество солнечной энергии.
 * targetY — высота, на которой солнце остановится.
 */
export function createSun({
    x,
    y = -30,
    targetY = y,
    value = 25,
    source = "sky",
    speed = 60,
    now = Date.now(),
} = {}) {
    return {
        id: `sun_${now}_${Math.random().toString(36).slice(2, 9)}`,

        x: Number.isFinite(x) ? x : 0,
        y: Number.isFinite(y) ? y : 0,
        targetY: Number.isFinite(targetY) ? targetY : 0,

        value: Math.max(
            0,
            Number.isFinite(value) ? value : 25
        ),

        source,
        speed: Math.max(0, speed),

        collected: false,
        alive: true,
        createdAt: now,
        expiresAt: now + 10000,
    };
}

/**
 * Создаёт солнце от подсолнуха.
 * Оно появляется рядом с растением и не падает с неба.
 */
export function createPlantSun(plant, now = Date.now()) {
    if (!plant) {
        return null;
    }

    const plantX = Number.isFinite(plant.x) ? plant.x : 0;
    const plantY = Number.isFinite(plant.y) ? plant.y : 0;

    return createSun({
        x: plantX + 25,
        y: plantY - 10,
        targetY: plantY - 10,
        value: 25,
        source: "plant",
        speed: 0,
        now,
    });
}

/**
 * Создаёт падающее с неба солнце.
 */
export function createSkySun(
    x,
    targetY,
    now = Date.now()
) {
    return createSun({
        x,
        y: -30,
        targetY,
        value: 25,
        source: "sky",
        speed: 60,
        now,
    });
}

/**
 * Обновляет движение солнца.
 *
 * deltaTime передаётся в секундах.
 */
export function updateSun(sun, deltaTime, now = Date.now()) {
    if (!sun || !sun.alive || sun.collected) {
        return;
    }

    const safeDelta = Math.max(
        0,
        Math.min(
            GAME_CONFIG.MAX_DELTA_TIME ?? 0.05,
            Number.isFinite(deltaTime) ? deltaTime : 0
        )
    );

    if (sun.y < sun.targetY) {
        sun.y = Math.min(
            sun.targetY,
            sun.y + sun.speed * safeDelta
        );
    }

    if (now >= sun.expiresAt) {
        sun.alive = false;
    }
}

/**
 * Обновляет все солнца.
 */
export function updateSuns(suns, deltaTime, now = Date.now()) {
    if (!Array.isArray(suns)) {
        return;
    }

    for (const sun of suns) {
        updateSun(sun, deltaTime, now);
    }

    cleanupSuns(suns);
}

/**
 * Проверяет, находится ли курсор внутри области солнца.
 */
export function isPointOnSun(
    sun,
    mouseX,
    mouseY,
    radius = GAME_CONFIG.SUN_HITBOX_SIZE / 2
) {
    if (
        !sun ||
        !sun.alive ||
        sun.collected ||
        !Number.isFinite(mouseX) ||
        !Number.isFinite(mouseY)
    ) {
        return false;
    }

    const dx = mouseX - sun.x;
    const dy = mouseY - sun.y;

    return dx * dx + dy * dy <= radius * radius;
}

/**
 * Собирает солнце и возвращает полученное количество энергии.
 * Возвращает 0, если солнце уже собрано или недоступно.
 */
export function collectSun(sun) {
    if (!sun || !sun.alive || sun.collected) {
        return 0;
    }

    sun.collected = true;
    sun.alive = false;

    return sun.value;
}

/**
 * Удаляет собранные и просроченные солнца.
 *
 * Возвращает количество удалённых объектов.
 */
export function cleanupSuns(suns) {
    if (!Array.isArray(suns)) {
        return 0;
    }

    const previousLength = suns.length;

    for (let i = suns.length - 1; i >= 0; i--) {
        const sun = suns[i];

        if (!sun || !sun.alive || sun.collected) {
            suns.splice(i, 1);
        }
    }

    return previousLength - suns.length;
}
