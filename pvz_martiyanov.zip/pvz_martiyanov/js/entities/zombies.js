
import { ZOMBIE_CONFIG, GAME_CONFIG } from "../core/config.js";

/**
 * Конфигурация зомби.
 * Типы должны совпадать с ключами в core/config.js.
 */

export function getZombieConfig(type) {
    return ZOMBIE_CONFIG[type] ?? ZOMBIE_CONFIG.normal;
}

/**
 * Создаёт объект зомби.
 *
 * x и y — координаты на игровом поле.
 * row — номер дорожки.
 * now — текущее время в миллисекундах.
 */
export function createZombie(type = "normal", row = 0, x, y, now = Date.now()) {
    const config = getZombieConfig(type);

    const defaultX = GAME_CONFIG.COLS * GAME_CONFIG.CELL_W;

    return {
        id: `zombie_${now}_${Math.random().toString(36).slice(2, 9)}`,
        type,
        row,
        x: Number.isFinite(x) ? x : defaultX,
        y: Number.isFinite(y)
            ? y
            : row * GAME_CONFIG.CELL_H,

        health: config.health,
        maxHealth: config.health,
        speed: config.speed,
        baseSpeed: config.speed,

        damagePerSecond: config.damagePerSecond,
        score: config.score ?? 10,

        alive: true,
        attacking: false,
        frozenUntil: 0,
        slowUntil: 0,

        createdAt: now,
        lastAttackAt: now,
    };
}

/**
 * Проверяет, жив ли зомби.
 */
export function isZombieAlive(zombie) {
    return Boolean(zombie) &&
        zombie.alive !== false &&
        zombie.health > 0;
}

/**
 * Замедляет зомби на указанное время.
 *
 * multiplier:
 * 0.5 — половина скорости.
 *
 * duration:
 * длительность эффекта в миллисекундах.
 */
export function slowZombie(
    zombie,
    multiplier = 0.5,
    duration = 3000,
    now = Date.now()
) {
    if (!isZombieAlive(zombie)) {
        return false;
    }

    const safeMultiplier = Math.max(
        0.1,
        Math.min(1, multiplier)
    );

    zombie.speed = zombie.baseSpeed * safeMultiplier;
    zombie.slowUntil = Math.max(
        zombie.slowUntil ?? 0,
        now + Math.max(0, duration)
    );

    return true;
}

/**
 * Замораживает зомби.
 *
 * Во время заморозки скорость становится равной нулю.
 * После окончания эффекта восстанавливается базовая скорость
 * с учётом оставшегося замедления.
 */
export function freezeZombie(
    zombie,
    duration = 2000,
    now = Date.now()
) {
    if (!isZombieAlive(zombie)) {
        return false;
    }

    zombie.frozenUntil = Math.max(
        zombie.frozenUntil ?? 0,
        now + Math.max(0, duration)
    );

    zombie.speed = 0;

    return true;
}

/**
 * Обновляет временные эффекты зомби.
 * Вызывается перед расчётом движения.
 */
export function updateZombieEffects(zombie, now = Date.now()) {
    if (!isZombieAlive(zombie)) {
        return;
    }

    if ((zombie.frozenUntil ?? 0) > now) {
        zombie.speed = 0;
        return;
    }

    zombie.frozenUntil = 0;

    if ((zombie.slowUntil ?? 0) > now) {
        const config = getZombieConfig(zombie.type);
        const slowMultiplier = zombie.baseSpeed > 0
            ? zombie.speed / zombie.baseSpeed
            : 1;

        // Сохраняем действующее замедление.
        zombie.speed = zombie.baseSpeed * Math.max(
            0.1,
            Math.min(1, slowMultiplier || 0.5)
        );

        if (!Number.isFinite(zombie.speed)) {
            zombie.speed = config.speed;
        }

        return;
    }

    zombie.slowUntil = 0;
    zombie.speed = zombie.baseSpeed;
}

/**
 * Наносит зомби урон.
 *
 * Возвращает true, если зомби был уничтожен этим ударом.
 */
export function damageZombie(zombie, damage) {
    if (!isZombieAlive(zombie)) {
        return false;
    }

    const safeDamage = Math.max(
        0,
        Number.isFinite(damage) ? damage : 0
    );

    zombie.health = Math.max(0, zombie.health - safeDamage);

    if (zombie.health <= 0) {
        zombie.alive = false;
        zombie.attacking = false;
        return true;
    }

    return false;
}

/**
 * Перемещает зомби влево.
 *
 * deltaTime — время кадра в секундах.
 * speed задаётся в единицах координат в секунду.
 */
export function moveZombie(zombie, deltaTime, now = Date.now()) {
    if (!isZombieAlive(zombie)) {
        return;
    }

    updateZombieEffects(zombie, now);

    if (zombie.attacking || zombie.speed <= 0) {
        return;
    }

    const safeDelta = Math.max(
        0,
        Math.min(
            GAME_CONFIG.MAX_DELTA_TIME ?? 0.05,
            Number.isFinite(deltaTime) ? deltaTime : 0
        )
    );

    zombie.x -= zombie.speed * safeDelta;
}

/**
 * Удаляет уничтоженных зомби из массива.
 *
 * Возвращает количество удалённых объектов.
 */
export function removeDeadZombies(zombies) {
    if (!Array.isArray(zombies)) {
        return 0;
    }

    const previousLength = zombies.length;

    for (let i = zombies.length - 1; i >= 0; i--) {
        if (!isZombieAlive(zombies[i])) {
            zombies.splice(i, 1);
        }
    }

    return previousLength - zombies.length;
}

/**
 * Возвращает число живых зомби.
 */
export function countAliveZombies(zombies) {
    if (!Array.isArray(zombies)) {
        return 0;
    }

    return zombies.filter(isZombieAlive).length;
}
