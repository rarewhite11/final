
import { GAME_CONFIG, PLANT_CONFIG } from "../core/config.js";

/**
 * Возвращает настройки растения.
 */
export function getPlantConfig(type) {
    return PLANT_CONFIG[type] ?? null;
}

/**
 * Проверяет, хватает ли солнечной энергии на растение.
 */
export function canAffordPlant(type, sun) {
    const config = getPlantConfig(type);

    return Boolean(
        config &&
        Number.isFinite(config.cost) &&
        Number.isFinite(sun) &&
        sun >= config.cost
    );
}

/**
 * Создаёт объект растения.
 *
 * x и y — координаты на игровом поле.
 * row и col — индексы клетки.
 */
export function createPlant(
    type,
    row,
    col,
    x,
    y,
    now = Date.now()
) {
    const config = getPlantConfig(type);

    if (!config) {
        throw new Error(`Неизвестный тип растения: ${type}`);
    }

    if (
        !Number.isInteger(row) ||
        !Number.isInteger(col) ||
        row < 0 ||
        row >= GAME_CONFIG.ROWS ||
        col < 0 ||
        col >= GAME_CONFIG.COLS
    ) {
        throw new RangeError("Координаты клетки вне игрового поля.");
    }

    return {
        id: `plant_${now}_${Math.random().toString(36).slice(2, 9)}`,

        type,
        row,
        col,

        x: Number.isFinite(x)
            ? x
            : col * GAME_CONFIG.CELL_W,

        y: Number.isFinite(y)
            ? y
            : row * GAME_CONFIG.CELL_H,

        width: GAME_CONFIG.CELL_W,
        height: GAME_CONFIG.CELL_H,

        health: config.health,
        maxHealth: config.health,

        alive: true,
        plantedAt: now,
        lastAttackAt: 0,
        lastSunAt: now,
        cooldownUntil: 0,
    };
}

/**
 * Проверяет, занята ли клетка живым растением.
 */
export function isCellOccupied(plants, row, col) {
    if (!Array.isArray(plants)) {
        return false;
    }

    return plants.some((plant) =>
        plant &&
        plant.alive !== false &&
        plant.health > 0 &&
        plant.row === row &&
        plant.col === col
    );
}

/**
 * Проверяет, можно ли посадить растение в клетку.
 */
export function canPlacePlant(
    plants,
    row,
    col,
    rows = GAME_CONFIG.ROWS,
    cols = GAME_CONFIG.COLS
) {
    if (
        !Number.isInteger(row) ||
        !Number.isInteger(col) ||
        row < 0 ||
        col < 0 ||
        row >= rows ||
        col >= cols
    ) {
        return false;
    }

    return !isCellOccupied(plants, row, col);
}

/**
 * Наносит растению урон.
 *
 * Возвращает true, если растение уничтожено этим ударом.
 */
export function damagePlant(plant, damage) {
    if (
        !plant ||
        plant.alive === false ||
        plant.health <= 0 ||
        !Number.isFinite(damage) ||
        damage < 0
    ) {
        return false;
    }

    plant.health = Math.max(0, plant.health - damage);

    if (plant.health === 0) {
        plant.alive = false;
        return true;
    }

    return false;
}

/**
 * Удаляет уничтоженные растения из массива.
 *
 * Возвращает количество удалённых объектов.
 */
export function removeDeadPlants(plants) {
    if (!Array.isArray(plants)) {
        return 0;
    }

    const previousLength = plants.length;

    for (let i = plants.length - 1; i >= 0; i--) {
        const plant = plants[i];

        if (!plant || plant.alive === false || plant.health <= 0) {
            plants.splice(i, 1);
        }
    }

    return previousLength - plants.length;
}

/**
 * Возвращает растение в указанной клетке.
 */
export function getPlantAtCell(plants, row, col) {
    if (!Array.isArray(plants)) {
        return null;
    }

    return plants.find((plant) =>
        plant &&
        plant.alive !== false &&
        plant.health > 0 &&
        plant.row === row &&
        plant.col === col
    ) ?? null;
}
