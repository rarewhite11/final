
import { GAME_CONFIG } from "../core/config.js";

/**
 * Создаёт снаряд растения.
 *
 * x, y — координаты снаряда.
 * row — дорожка, на которой летит снаряд.
 * damage — урон при попадании.
 */
export function createProjectile({
    type = "pea",
    x,
    y,
    row,
    damage = 20,
    speed = 350,
    owner = null,
    now = Date.now(),
} = {}) {
    return {
        id: `projectile_${now}_${Math.random().toString(36).slice(2, 9)}`,
        type,
        x: Number.isFinite(x) ? x : 0,
        y: Number.isFinite(y) ? y : 0,
        row: Number.isInteger(row) ? row : 0,

        damage: Math.max(0, damage),
        speed: Math.max(0, speed),

        owner,
        alive: true,
        createdAt: now,
    };
}

/**
 * Перемещает снаряд вправо.
 *
 * deltaTime передаётся в секундах.
 */
export function moveProjectile(projectile, deltaTime) {
    if (!projectile || projectile.alive === false) {
        return;
    }

    const safeDelta = Math.max(
        0,
        Math.min(
            GAME_CONFIG.MAX_DELTA_TIME ?? 0.05,
            Number.isFinite(deltaTime) ? deltaTime : 0
        )
    );

    projectile.x += projectile.speed * safeDelta;
}

/**
 * Проверяет пересечение снаряда с прямоугольником цели.
 */
export function projectileHitsTarget(
    projectile,
    target,
    projectileRadius = 10
) {
    if (!projectile || !target) {
        return false;
    }

    if (projectile.alive === false || target.alive === false) {
        return false;
    }

    const targetX = Number.isFinite(target.x) ? target.x : 0;
    const targetY = Number.isFinite(target.y) ? target.y : 0;

    const width = Number.isFinite(target.width)
        ? target.width
        : 0;

    const height = Number.isFinite(target.height)
        ? target.height
        : 0;

    const radius = Math.max(0, projectileRadius);

    return (
        projectile.x + radius >= targetX &&
        projectile.x - radius <= targetX + width &&
        projectile.y + radius >= targetY &&
        projectile.y - radius <= targetY + height
    );
}

/**
 * Проверяет, находится ли снаряд на той же дорожке,
 * что и зомби.
 */
export function isSameLane(projectile, zombie) {
    return Boolean(projectile && zombie) &&
        projectile.row === zombie.row;
}

/**
 * Ищет первого живого зомби на дорожке,
 * которого достиг снаряд.
 *
 * Для проверки нужны координаты и размеры зомби.
 */
export function findProjectileTarget(
    projectile,
    zombies,
    zombieWidth = 80,
    zombieHeight = 100
) {
    if (!projectile || !Array.isArray(zombies)) {
        return null;
    }

    const candidates = zombies
        .filter((zombie) => {
            if (!zombie || zombie.alive === false) {
                return false;
            }

            if (zombie.health <= 0) {
                return false;
            }

            return isSameLane(projectile, zombie);
        })
        .sort((a, b) => a.x - b.x);

    for (const zombie of candidates) {
        const target = {
            ...zombie,
            width: Number.isFinite(zombie.width)
                ? zombie.width
                : zombieWidth,
            height: Number.isFinite(zombie.height)
                ? zombie.height
                : zombieHeight,
        };

        if (projectileHitsTarget(projectile, target)) {
            return zombie;
        }
    }

    return null;
}

/**
 * Отмечает снаряд как уничтоженный после попадания.
 */
export function consumeProjectile(projectile) {
    if (!projectile) {
        return;
    }

    projectile.alive = false;
}

/**
 * Удаляет использованные снаряды и снаряды,
 * вышедшие за границы игрового поля.
 */
export function cleanupProjectiles(projectiles, margin = 100) {
    if (!Array.isArray(projectiles)) {
        return 0;
    }

    const maxX =
        GAME_CONFIG.COLS * GAME_CONFIG.CELL_W + margin;

    const maxY =
        GAME_CONFIG.ROWS * GAME_CONFIG.CELL_H + margin;

    const previousLength = projectiles.length;

    for (let i = projectiles.length - 1; i >= 0; i--) {
        const projectile = projectiles[i];

        if (
            !projectile ||
            projectile.alive === false ||
            projectile.x < -margin ||
            projectile.x > maxX ||
            projectile.y < -margin ||
            projectile.y > maxY
        ) {
            projectiles.splice(i, 1);
        }
    }

    return previousLength - projectiles.length;
}

/**
 * Обновляет все снаряды за один игровой кадр.
 */
export function updateProjectiles(projectiles, deltaTime) {
    if (!Array.isArray(projectiles)) {
        return;
    }

    for (const projectile of projectiles) {
        moveProjectile(projectile, deltaTime);
    }

    cleanupProjectiles(projectiles);
}

import { GAME_CONFIG } from "../core/config.js";

/**
 * Создаёт снаряд растения.
 *
 * x, y — координаты снаряда.
 * row — дорожка, на которой летит снаряд.
 * damage — урон при попадании.
 */
export function createProjectile({
    type = "pea",
    x,
    y,
    row,
    damage = 20,
    speed = 350,
    owner = null,
    now = Date.now(),
} = {}) {
    return {
        id: `projectile_${now}_${Math.random().toString(36).slice(2, 9)}`,
        type,
        x: Number.isFinite(x) ? x : 0,
        y: Number.isFinite(y) ? y : 0,
        row: Number.isInteger(row) ? row : 0,

        damage: Math.max(0, damage),
        speed: Math.max(0, speed),

        owner,
        alive: true,
        createdAt: now,
    };
}

/**
 * Перемещает снаряд вправо.
 *
 * deltaTime передаётся в секундах.
 */
export function moveProjectile(projectile, deltaTime) {
    if (!projectile || projectile.alive === false) {
        return;
    }

    const safeDelta = Math.max(
        0,
        Math.min(
            GAME_CONFIG.MAX_DELTA_TIME ?? 0.05,
            Number.isFinite(deltaTime) ? deltaTime : 0
        )
    );

    projectile.x += projectile.speed * safeDelta;
}

/**
 * Проверяет пересечение снаряда с прямоугольником цели.
 */
export function projectileHitsTarget(
    projectile,
    target,
    projectileRadius = 10
) {
    if (!projectile || !target) {
        return false;
    }

    if (projectile.alive === false || target.alive === false) {
        return false;
    }

    const targetX = Number.isFinite(target.x) ? target.x : 0;
    const targetY = Number.isFinite(target.y) ? target.y : 0;

    const width = Number.isFinite(target.width)
        ? target.width
        : 0;

    const height = Number.isFinite(target.height)
        ? target.height
        : 0;

    const radius = Math.max(0, projectileRadius);

    return (
        projectile.x + radius >= targetX &&
        projectile.x - radius <= targetX + width &&
        projectile.y + radius >= targetY &&
        projectile.y - radius <= targetY + height
    );
}

/**
 * Проверяет, находится ли снаряд на той же дорожке,
 * что и зомби.
 */
export function isSameLane(projectile, zombie) {
    return Boolean(projectile && zombie) &&
        projectile.row === zombie.row;
}

/**
 * Ищет первого живого зомби на дорожке,
 * которого достиг снаряд.
 *
 * Для проверки нужны координаты и размеры зомби.
 */
export function findProjectileTarget(
    projectile,
    zombies,
    zombieWidth = 80,
    zombieHeight = 100
) {
    if (!projectile || !Array.isArray(zombies)) {
        return null;
    }

    const candidates = zombies
        .filter((zombie) => {
            if (!zombie || zombie.alive === false) {
                return false;
            }

            if (zombie.health <= 0) {
                return false;
            }

            return isSameLane(projectile, zombie);
        })
        .sort((a, b) => a.x - b.x);

    for (const zombie of candidates) {
        const target = {
            ...zombie,
            width: Number.isFinite(zombie.width)
                ? zombie.width
                : zombieWidth,
            height: Number.isFinite(zombie.height)
                ? zombie.height
                : zombieHeight,
        };

        if (projectileHitsTarget(projectile, target)) {
            return zombie;
        }
    }

    return null;
}

/**
 * Отмечает снаряд как уничтоженный после попадания.
 */
export function consumeProjectile(projectile) {
    if (!projectile) {
        return;
    }

    projectile.alive = false;
}

/**
 * Удаляет использованные снаряды и снаряды,
 * вышедшие за границы игрового поля.
 */
export function cleanupProjectiles(projectiles, margin = 100) {
    if (!Array.isArray(projectiles)) {
        return 0;
    }

    const maxX =
        GAME_CONFIG.COLS * GAME_CONFIG.CELL_W + margin;

    const maxY =
        GAME_CONFIG.ROWS * GAME_CONFIG.CELL_H + margin;

    const previousLength = projectiles.length;

    for (let i = projectiles.length - 1; i >= 0; i--) {
        const projectile = projectiles[i];

        if (
            !projectile ||
            projectile.alive === false ||
            projectile.x < -margin ||
            projectile.x > maxX ||
            projectile.y < -margin ||
            projectile.y > maxY
        ) {
            projectiles.splice(i, 1);
        }
    }

    return previousLength - projectiles.length;
}

/**
 * Обновляет все снаряды за один игровой кадр.
 */
export function updateProjectiles(projectiles, deltaTime) {
    if (!Array.isArray(projectiles)) {
        return;
    }

    for (const projectile of projectiles) {
        moveProjectile(projectile, deltaTime);
    }

    cleanupProjectiles(projectiles);
}
