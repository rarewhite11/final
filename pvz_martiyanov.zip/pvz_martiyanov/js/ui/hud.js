
/**
 * Подготовка данных для игрового интерфейса (HUD).
 *
 * Этот модуль не рисует интерфейс самостоятельно.
 * Он возвращает данные, которые можно отобразить
 * через Canvas или DOM после интеграции с игрой.
 */

/**
 * Возвращает безопасное числовое значение.
 */
function safeNumber(value, fallback = 0) {
    return Number.isFinite(value) ? value : fallback;
}

/**
 * Собирает основные показатели игры.
 */
export function getHudData(gameState, waveState = null) {
    const state = gameState ?? {};

    return {
        sun: Math.max(0, safeNumber(state.sun)),
        score: Math.max(0, safeNumber(state.score)),
        kills: Math.max(0, safeNumber(state.kills)),

        wave: Math.max(
            1,
            safeNumber(
                waveState?.number ?? state.currentWave,
                1
            )
        ),

        totalWaves: Math.max(
            1,
            safeNumber(state.totalWaves, 100)
        ),

        aliveZombies: countAlive(state.zombies),
        alivePlants: countAlive(state.plants),

        paused: Boolean(state.paused),
        running: Boolean(state.running),
        gameOver: Boolean(state.gameOver),
    };
}

/**
 * Считает живые объекты.
 */
function countAlive(objects) {
    if (!Array.isArray(objects)) {
        return 0;
    }

    return objects.filter((object) => {
        return (
            object &&
            object.alive !== false &&
            safeNumber(object.health, 1) > 0
        );
    }).length;
}

/**
 * Форматирует число для отображения в интерфейсе.
 */
export function formatHudNumber(value) {
    return Math.max(
        0,
        safeNumber(value)
    ).toLocaleString("ru-RU");
}

/**
 * Формирует текст текущей волны.
 */
export function formatWaveLabel(waveState) {
    const wave = Math.max(
        1,
        Math.floor(safeNumber(waveState?.number, 1))
    );

    return `ВОЛНА ${wave}`;
}

/**
 * Возвращает текст состояния игры.
 */
export function getGameStatus(gameState) {
    if (!gameState) {
        return "ОЖИДАНИЕ";
    }

    if (gameState.gameOver) {
        return "ИГРА ОКОНЧЕНА";
    }

    if (gameState.paused) {
        return "ПАУЗА";
    }

    if (gameState.running) {
        return "ИГРА ИДЁТ";
    }

    return "ГОТОВ К ИГРЕ";
}

/**
 * Возвращает данные прогресса волны.
 */
export function getWaveProgress(waveState) {
    if (!waveState) {
        return {
            spawned: 0,
            defeated: 0,
            total: 0,
            percent: 0,
        };
    }

    const total = Math.max(
        0,
        Math.floor(safeNumber(waveState.totalZombies))
    );

    const spawned = Math.min(
        total,
        Math.max(
            0,
            Math.floor(safeNumber(waveState.spawnedZombies))
        )
    );

    const defeated = Math.min(
        spawned,
        Math.max(
            0,
            Math.floor(safeNumber(waveState.defeatedZombies))
        )
    );

    return {
        spawned,
        defeated,
        total,
        percent: total > 0
            ? Math.round((defeated / total) * 100)
            : 0,
    };
}
