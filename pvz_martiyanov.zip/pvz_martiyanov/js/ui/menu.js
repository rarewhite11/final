
/**
 * Навигация между экранами игры.
 *
 * Модуль не создаёт HTML и не меняет CSS.
 * Он хранит активный экран и предоставляет функции перехода.
 */

export const SCREEN = Object.freeze({
    MENU: "menu",
    GAME: "game",
    SETTINGS: "settings",
    GAME_OVER: "game-over",
});

/**
 * Создаёт состояние навигации.
 */
export function createMenuState(initialScreen = SCREEN.MENU) {
    const allowedScreens = Object.values(SCREEN);

    return {
        currentScreen: allowedScreens.includes(initialScreen)
            ? initialScreen
            : SCREEN.MENU,

        previousScreen: null,
    };
}

/**
 * Переключает экран.
 *
 * Возвращает true, если переход выполнен.
 */
export function navigateTo(menuState, screen) {
    if (!menuState) {
        return false;
    }

    if (!Object.values(SCREEN).includes(screen)) {
        return false;
    }

    if (menuState.currentScreen === screen) {
        return true;
    }

    menuState.previousScreen = menuState.currentScreen;
    menuState.currentScreen = screen;

    return true;
}

/**
 * Возвращает главное меню.
 */
export function openMainMenu(menuState) {
    return navigateTo(menuState, SCREEN.MENU);
}

/**
 * Открывает игровой экран.
 */
export function openGameScreen(menuState) {
    return navigateTo(menuState, SCREEN.GAME);
}

/**
 * Открывает настройки.
 */
export function openSettingsScreen(menuState) {
    return navigateTo(menuState, SCREEN.SETTINGS);
}

/**
 * Открывает экран поражения.
 */
export function openGameOverScreen(menuState) {
    return navigateTo(menuState, SCREEN.GAME_OVER);
}

/**
 * Возвращает предыдущий экран.
 */
export function goBack(menuState) {
    if (!menuState || !menuState.previousScreen) {
        return false;
    }

    const previous = menuState.previousScreen;
    menuState.previousScreen = menuState.currentScreen;
    menuState.currentScreen = previous;

    return true;
}

/**
 * Проверяет, открыт ли игровой экран.
 */
export function isGameScreen(menuState) {
    return menuState?.currentScreen === SCREEN.GAME;
}

/**
 * Проверяет, открыто ли главное меню.
 */
export function isMainMenu(menuState) {
    return menuState?.currentScreen === SCREEN.MENU;
}

/**
 * Проверяет, открыты ли настройки.
 */
export function isSettingsScreen(menuState) {
    return menuState?.currentScreen === SCREEN.SETTINGS;
}

/**
 * Возвращает CSS-класс для выбранного экрана.
 */
export function getScreenClass(screen) {
    const classes = {
        [SCREEN.MENU]: "screen screen-menu",
        [SCREEN.GAME]: "screen screen-game",
        [SCREEN.SETTINGS]: "screen screen-settings",
        [SCREEN.GAME_OVER]: "screen screen-game-over",
    };

    return classes[screen] ?? "screen";
}
