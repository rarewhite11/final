
/**
 * Управление состоянием паузы.
 *
 * Этот модуль отвечает за логику.
 * Визуальное оформление оверлея будет настраиваться
 * отдельно в style.css при интеграции.
 */

/**
 * Включает паузу.
 */
export function pauseGame(gameState) {
    if (!gameState || gameState.gameOver) {
        return false;
    }

    gameState.paused = true;
    return true;
}

/**
 * Продолжает игру.
 */
export function resumeGame(gameState) {
    if (!gameState || gameState.gameOver) {
        return false;
    }

    gameState.paused = false;
    return true;
}

/**
 * Переключает паузу.
 * Возвращает новое состояние: true — пауза включена.
 */
export function togglePause(gameState) {
    if (!gameState || gameState.gameOver) {
        return false;
    }

    gameState.paused = !gameState.paused;
    return gameState.paused;
}

/**
 * Проверяет, стоит ли игровой процесс на паузе.
 */
export function isGamePaused(gameState) {
    return Boolean(gameState?.paused);
}

/**
 * Переключает паузу по клавише Escape.
 *
 * Вызывай эту функцию из обработчика клавиатуры,
 * когда игра активна и открыта.
 */
export function handlePauseKey(event, gameState) {
    if (!event || event.key !== "Escape") {
        return false;
    }

    if (
        event.repeat ||
        event.target?.tagName === "INPUT" ||
        event.target?.tagName === "TEXTAREA"
    ) {
        return false;
    }

    event.preventDefault();

    return togglePause(gameState);
}

/**
 * Возвращает текст кнопки паузы.
 */
export function getPauseButtonLabel(gameState) {
    return isGamePaused(gameState)
        ? "ПРОДОЛЖИТЬ"
        : "ПАУЗА";
}

/**
 * Возвращает параметры отображения оверлея.
 * Эти значения можно использовать при создании DOM-интерфейса.
 */
export function getPauseOverlayState(gameState) {
    const visible = isGamePaused(gameState);

    return {
        visible,
        className: visible ? "pause-overlay is-visible" : "pause-overlay",
        title: "ПАУЗА",
        continueLabel: "ПРОДОЛЖИТЬ",
        menuLabel: "В ГЛАВНОЕ МЕНЮ",
        blocksGameInput: visible,
    };
}
