
import { PLANT_CONFIG } from "../core/config.js";
import {
    createProjectile,
    findProjectileTarget,
    consumeProjectile,
    updateProjectiles,
} from "../entities/projectiles.js";
import {
    damageZombie,
    slowZombie,
    removeDeadZombies,
} from "../entities/zombies.js";

/**
 * Определяет, может ли растение атаковать.
 */
export function canPlantAttack(plant) {
    if (!plant || plant.alive === false || plant.health <= 0) {
        return false;
    }

    const config = PLANT_CONFIG[plant.type];

    if (!config || !Number.isFinite(config.damage)) {
        return false;
    }

    return true;
}

/**
 * Проверяет, есть ли живой зомби впереди растения
 * на той же дорожке.
 */
export function hasTargetAhead(plant, zombies) {
    if (!plant || !Array.isArray(zombies)) {
        return false;
    }

    return zombies.some((zombie) => {
        if (
            !zombie ||
            zombie.alive === false ||
            zombie.health <= 0
        ) {
            return false;
        }

        return (
            zombie.row === plant.row &&
            zombie.x > plant.x
        );
    });
}

/**
 * Создаёт снаряд для атакующего растения.
 *
 * Важно: координаты и скорость необходимо согласовать
 * с системой отрисовки при интеграции со старой игрой.
 */
export function plantShoot(plant, now = Date.now()) {
    if (!canPlantAttack(plant)) {
        return null;
    }

    const config = PLANT_CONFIG[plant.type];

    const projectileType = plant.type === "iceshooter"
        ? "ice"
        : "pea";

    const projectile = createProjectile({
        type: projectileType,
        x: (plant.x ?? 0) + (plant.width ?? 40),
        y: (plant.y ?? 0) + (plant.height ?? 40) / 2,
        row: plant.row,
        damage: config.damage,
        speed: 350,
        owner: plant.id ?? null,
        now,
    });

    if (projectileType === "ice") {
        projectile.slowMultiplier = config.slowMultiplier ?? 0.5;
        projectile.slowDuration = (config.slowDuration ?? 3) * 1000;
    }

    return projectile;
}

/**
 * Наносит урон зомби при попадании снаряда.
 */
export function applyProjectileHit(projectile, zombie, now = Date.now()) {
    if (
        !projectile ||
        !zombie ||
        projectile.alive === false ||
        zombie.alive === false
    ) {
        return {
            hit: false,
            killed: false,
            damage: 0,
        };
    }

    const damage = Math.max(
        0,
        Number.isFinite(projectile.damage)
            ? projectile.damage
            : 0
    );

    const killed = damageZombie(zombie, damage);

    if (projectile.type === "ice") {
        slowZombie(
            zombie,
            projectile.slowMultiplier ?? 0.5,
            projectile.slowDuration ?? 3000,
            now
        );
    }

    consumeProjectile(projectile);

    return {
        hit: true,
        killed,
        damage,
    };
}

/**
 * Обновляет полёт снарядов и обрабатывает попадания.
 *
 * Размеры зомби можно передать явно, если они отличаются
 * от стандартных значений.
 */
export function updateCombat(
    gameState,
    deltaTime,
    now = Date.now(),
    options = {}
) {
    if (!gameState) {
        return {
            hits: 0,
            kills: 0,
        };
    }

    const projectiles = gameState.projectiles;
    const zombies = gameState.zombies;

    if (!Array.isArray(projectiles) || !Array.isArray(zombies)) {
        return {
            hits: 0,
            kills: 0,
        };
    }

    updateProjectiles(projectiles, deltaTime);

    let hits = 0;
    let kills = 0;

    const zombieWidth = options.zombieWidth ?? 80;
    const zombieHeight = options.zombieHeight ?? 100;

    for (const projectile of projectiles) {
        if (!projectile || projectile.alive === false) {
            continue;
        }

        const target = findProjectileTarget(
            projectile,
            zombies,
            zombieWidth,
            zombieHeight
        );

        if (!target) {
            continue;
        }

        const result = applyProjectileHit(
            projectile,
            target,
            now
        );

        if (result.hit) {
            hits++;
        }

        if (result.killed) {
            kills++;

            if (typeof gameState.registerKill === "function") {
                gameState.registerKill(target);
            } else {
                gameState.kills = (gameState.kills ?? 0) + 1;
                gameState.score = (gameState.score ?? 0) +
                    (target.score ?? 10);
            }
        }
    }

    // Удаляем использованные снаряды и уничтоженных зомби.
    for (let i = projectiles.length - 1; i >= 0; i--) {
        if (!projectiles[i] || projectiles[i].alive === false) {
            projectiles.splice(i, 1);
        }
    }

    removeDeadZombies(zombies);

    return {
        hits,
        kills,
    };
}
