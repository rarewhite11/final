
import { PLANT_CONFIG, GAME_CONFIG } from "../core/config.js";

/**
 * Возвращает текущий баланс солнечной энергии.
 */
export function getSunBalance(gameState) {
    if (!gameState) {
        return 0;
    }

    return Math.max(
        0,
        Number.isFinite(gameState.sun) ? gameState.sun : 0
    );
}

/**
 * Возвращает стоимость растения.
 */
export function getPlantCost(type) {
    const plant = PLANT_CONFIG[type];

    if (!plant || !Number.isFinite(plant.cost)) {
        return null;
    }

    return plant.cost;
}

/**
 * Проверяет, хватает ли энергии для покупки растения.
 */
export function canAfford(gameState, plantType) {
    const cost = getPlantCost(plantType);

    if (cost === null) {
        return false;
    }

    return getSunBalance(gameState) >= cost;
}

/**
 * Списывает солнечную энергию.
 *
 * Возвращает true при успешном списании.
 * Не списывает энергию, если её недостаточно.
 */
export function spendSun(gameState, amount) {
    if (!gameState || !Number.isFinite(amount) || amount < 0) {
        return false;
    }

    const balance = getSunBalance(gameState);

    if (balance < amount) {
        return false;
    }

    gameState.sun = balance - amount;
    return true;
}

/**
 * Покупает растение: проверяет баланс и списывает стоимость.
 *
 * Эта функция только проводит оплату.
 * Создание и размещение растения выполняются отдельно.
 */
export function purchasePlant(gameState, plantType) {
    const cost = getPlantCost(plantType);

    if (cost === null) {
        return {
            success: false,
            reason: "unknown_plant",
            balance: getSunBalance(gameState),
        };
    }

    if (!canAfford(gameState, plantType)) {
        return {
            success: false,
            reason: "not_enough_sun",
            balance: getSunBalance(gameState),
            cost,
        };
    }

    const success = spendSun(gameState, cost);

    if (!success) {
        return {
            success: false,
            reason: "not_enough_sun",
            balance: getSunBalance(gameState),
            cost,
        };
    }

    return {
        success: true,
        reason: null,
        balance: getSunBalance(gameState),
        cost,
    };
}

/**
 * Начисляет энергию за собранное солнце.
 *
 * Возвращает количество фактически начисленных единиц.
 */
export function addSun(gameState, amount = 25) {
    if (
        !gameState ||
        !Number.isFinite(amount) ||
        amount <= 0
    ) {
        return 0;
    }

    const current = getSunBalance(gameState);
    gameState.sun = current + amount;

    return amount;
}

/**
 * Собирает солнце и начисляет энергию.
 *
 * Объект sun должен быть создан модулем entities/sun.js.
 * Повторный сбор одного солнца не начисляет энергию.
 */
export function collectSunForEconomy(gameState, sun) {
    if (!gameState || !sun || !sun.alive || sun.collected) {
        return 0;
    }

    const value = Number.isFinite(sun.value) ? sun.value : 0;

    if (value <= 0) {
        return 0;
    }

    sun.collected = true;
    sun.alive = false;

    return addSun(gameState, value);
}

/**
 * Сбрасывает баланс к начальному значению.
 */
export function resetEconomy(gameState) {
    if (!gameState) {
        return;
    }

    gameState.sun = GAME_CONFIG.STARTING_SUN;
}
