
import { GAME_CONFIG, BALANCE_CONFIG, ZOMBIE_CONFIG } from "../core/config.js";
import { createZombie } from "../entities/zombies.js";

export function getZombieCountForWave(wave) {
    const safeWave = Math.max(1, Math.floor(wave || 1));
    const base = BALANCE_CONFIG.baseZombiesPerWave ?? 3;
    const additional = BALANCE_CONFIG.additionalZombiesPerWave ?? 1;

    return Math.max(
        1,
        Math.floor(base + (safeWave - 1) * additional)
    );
}

export function getAvailableZombieTypes(wave) {
    const safeWave = Math.max(1, Math.floor(wave || 1));

    return Object.entries(ZOMBIE_CONFIG)
        .filter(([, config]) => safeWave >= (config.minWave ?? 1))
        .map(([type]) => type);
}

export function chooseZombieType(wave, random = Math.random) {
    const safeWave = Math.max(1, Math.floor(wave || 1));
    const earlyLimit = BALANCE_CONFIG.earlyWaveLimit ?? 5;
    const specialChance = BALANCE_CONFIG.earlyWaveSpecialZombieChance ?? 0;

    if (safeWave <= earlyLimit && specialChance <= 0) {
        return "normal";
    }

    const available = getAvailableZombieTypes(safeWave);

    const weightedTypes = [];

    for (const type of available) {
        const config = ZOMBIE_CONFIG[type];
        const weight = type === "normal" ? 10 : 2;

        if (config) {
            for (let i = 0; i < weight; i++) {
                weightedTypes.push(type);
            }
        }
    }

    if (weightedTypes.length === 0) {
        return "normal";
    }

    const index = Math.min(
        weightedTypes.length - 1,
        Math.floor(random() * weightedTypes.length)
    );

    return weightedTypes[index];
}

export function chooseZombieRow(
    rows = GAME_CONFIG.ROWS,
    random = Math.random
) {
    const safeRows = Math.max(1, Math.floor(rows));

    return Math.min(
        safeRows - 1,
        Math.floor(random() * safeRows)
    );
}

export function createWaveState(wave = 1) {
    const number = Math.max(1, Math.floor(wave || 1));

    return {
        number,
        totalZombies: getZombieCountForWave(number),
        spawnedZombies: 0,
        defeatedZombies: 0,
        started: false,
        completed: false,
        nextSpawnAt: 0,
    };
}

export function getSpawnInterval(wave) {
    const safeWave = Math.max(1, Math.floor(wave || 1));

    return Math.max(
        1200,
        4000 - (safeWave - 1) * 100
    );
}

export function isSpawnDue(waveState, now = Date.now()) {
    if (
        !waveState ||
        waveState.completed ||
        waveState.spawnedZombies >= waveState.totalZombies
    ) {
        return false;
    }

    return now >= waveState.nextSpawnAt;
}

export function spawnNextZombie(
    waveState,
    zombies,
    options = {}
) {
    if (
        !waveState ||
        !Array.isArray(zombies) ||
        waveState.completed ||
        waveState.spawnedZombies >= waveState.totalZombies
    ) {
        return null;
    }

    const now = options.now ?? Date.now();
    const row = options.row ?? chooseZombieRow(options.rows ?? GAME_CONFIG.ROWS);
    const type = options.type ?? chooseZombieType(waveState.number);

    const spawnX = Number.isFinite(options.spawnX)
        ? options.spawnX
        : GAME_CONFIG.COLS * GAME_CONFIG.CELL_W;

    const y = row * GAME_CONFIG.CELL_H;

    const zombie = createZombie(
        type,
        row,
        spawnX,
        y,
        now
    );

    zombies.push(zombie);

    waveState.spawnedZombies += 1;
    waveState.started = true;
    waveState.nextSpawnAt = now + getSpawnInterval(waveState.number);

    return zombie;
}

export function registerWaveKill(waveState) {
    if (!waveState || waveState.completed) {
        return;
    }

    waveState.defeatedZombies = Math.min(
        waveState.totalZombies,
        waveState.defeatedZombies + 1
    );
}

export function isWaveComplete(waveState, zombies = []) {
    if (!waveState) {
        return false;
    }

    const hasLivingZombies = Array.isArray(zombies) &&
        zombies.some((zombie) =>
            zombie &&
            zombie.alive !== false &&
            zombie.health > 0
        );

    const complete =
        waveState.spawnedZombies >= waveState.totalZombies &&
        !hasLivingZombies;

    if (complete) {
        waveState.completed = true;
    }

    return complete;
}

export function createNextWave(waveState) {
    const nextWave = (waveState?.number ?? 0) + 1;
    return createWaveState(nextWave);
}
