
import { PLANT_CONFIG, GAME_CONFIG } from "../core/config.js";
import {
    createPlant,
    canPlacePlant,
    isCellOccupied,
} from "../entities/plants.js";
import { purchasePlant } from "./economy.js";

/**
 * Проверяет, существует ли такой тип растения.
 */
export function isValidPlantType(type) {
    return Object.prototype.hasOwnProperty.call(
        PLANT_CONFIG,
        type
    );
}

/**
 * Проверяет, можно ли посадить растение.
 */
export function canPlantAt(
    gameState,
    type,
    row,
    col
) {
    if (!gameState || gameState.paused || gameState.gameOver) {
        return {
            allowed: false,
            reason: "game_inactive",
        };
    }

    if (!isValidPlantType(type)) {
        return {
            allowed: false,
            reason: "unknown_plant",
        };
    }

    if (
        !Number.isInteger(row) ||
        !Number.isInteger(col) ||
        row < 0 ||
        row >= GAME_CONFIG.ROWS ||
        col < 0 ||
        col >= GAME_CONFIG.COLS
    ) {
        return {
            allowed: false,
            reason: "outside_field",
        };
    }

    if (isCellOccupied(gameState.plants, row, col)) {
        return {
            allowed: false,
            reason: "cell_occupied",
        };
    }

    const cost = PLANT_CONFIG[type].cost;

    if (gameState.sun < cost) {
        return {
            allowed: false,
            reason: "not_enough_sun",
            cost,
        };
    }

    return {
        allowed: true,
        reason: null,
        cost,
    };
}

/**
 * Сажает растение.
 *
 * Сначала проверяет клетку и баланс, затем списывает энергию
 * и добавляет растение в массив состояния игры.
 */
export function plantAt(
    gameState,
    type,
    row,
    col,
    options = {}
) {
    const check = canPlantAt(gameState, type, row, col);

    if (!check.allowed) {
        return {
            success: false,
            reason: check.reason,
            plant: null,
        };
    }

    const cost = check.cost;

    // Повторная проверка перед списанием.
    // Это защищает от изменения состояния между проверкой и покупкой.
    if (gameState.sun < cost) {
        return {
            success: false,
            reason: "not_enough_sun",
            plant: null,
        };
    }

    const payment = purchasePlant(gameState, type);

    if (!payment.success) {
        return {
            success: false,
            reason: payment.reason,
            plant: null,
        };
    }

    const x = Number.isFinite(options.x)
        ? options.x
        : col * GAME_CONFIG.CELL_W;

    const y = Number.isFinite(options.y)
        ? options.y
        : row * GAME_CONFIG.CELL_H;

    let plant;

    try {
        plant = createPlant(
            type,
            row,
            col,
            x,
            y,
            options.now ?? Date.now()
        );
    } catch (error) {
        // Если создание объекта завершилось ошибкой,
        // возвращаем списанную энергию.
        gameState.sun += cost;
        throw error;
    }

    gameState.plants.push(plant);

    return {
        success: true,
        reason: null,
        plant,
        remainingSun: gameState.sun,
    };
}

/**
 * Удаляет растение из выбранной клетки.
 * Возвращает удалённое растение или null.
 */
export function removePlantAt(gameState, row, col) {
    if (!gameState || !Array.isArray(gameState.plants)) {
        return null;
    }

    const index = gameState.plants.findIndex((plant) =>
        plant &&
        plant.alive !== false &&
        plant.health > 0 &&
        plant.row === row &&
        plant.col === col
    );

    if (index === -1) {
        return null;
    }

    const [plant] = gameState.plants.splice(index, 1);

    return plant;
}

/**
 * Возвращает растение, которое сейчас находится в клетке.
 */
export function getPlantAt(gameState, row, col) {
    if (!gameState || !Array.isArray(gameState.plants)) {
        return null;
    }

    return gameState.plants.find((plant) =>
        plant &&
        plant.alive !== false &&
        plant.health > 0 &&
        plant.row === row &&
        plant.col === col
    ) ?? null;
}
