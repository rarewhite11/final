
import { GAME_CONFIG } from "../core/config.js";
import { togglePause } from "../ui/pause.js";

/**
 * Преобразует координаты указателя браузера
 * в координаты игрового Canvas.
 */
export function getCanvasPoint(event, canvas) {
    if (!event || !canvas) {
        return null;
    }

    const rect = canvas.getBoundingClientRect();

    if (rect.width <= 0 || rect.height <= 0) {
        return null;
    }

    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    return {
        x: (event.clientX - rect.left) * scaleX,
        y: (event.clientY - rect.top) * scaleY,
    };
}

/**
 * Определяет клетку, на которую нажал игрок.
 */
export function getCellFromPoint(x, y) {
    if (!Number.isFinite(x) || !Number.isFinite(y)) {
        return null;
    }

    const col = Math.floor(x / GAME_CONFIG.CELL_W);
    const row = Math.floor(y / GAME_CONFIG.CELL_H);

    if (
        row < 0 ||
        row >= GAME_CONFIG.ROWS ||
        col < 0 ||
        col >= GAME_CONFIG.COLS
    ) {
        return null;
    }

    return { row, col };
}

/**
 * Обрабатывает клик по игровому Canvas.
 *
 * onCellClick вызывается, когда игрок нажимает на клетку.
 * onCanvasClick позволяет дополнительно обработать координаты.
 */
export function handleCanvasClick(
    event,
    canvas,
    {
        gameState,
        onCellClick,
        onCanvasClick,
    } = {}
) {
    if (!gameState || gameState.paused || gameState.gameOver) {
        return false;
    }

    const point = getCanvasPoint(event, canvas);

    if (!point) {
        return false;
    }

    const cell = getCellFromPoint(point.x, point.y);

    if (cell && typeof onCellClick === "function") {
        onCellClick(cell, point, event);
    }

    if (typeof onCanvasClick === "function") {
        onCanvasClick(point, cell, event);
    }

    return true;
}

/**
 * Создаёт обработчики ввода и возвращает функцию
 * для удаления всех зарегистрированных событий.
 */
export function attachGameInput({
    canvas,
    gameState,
    onCellClick,
    onCanvasClick,
    onEscape,
} = {}) {
    if (!canvas || !gameState) {
        throw new Error(
            "Для подключения управления нужны canvas и gameState."
        );
    }

    function handleClick(event) {
        handleCanvasClick(event, canvas, {
            gameState,
            onCellClick,
            onCanvasClick,
        });
    }

    function handleKeyDown(event) {
        if (event.key !== "Escape" || event.repeat) {
            return;
        }

        const target = event.target;

        if (
            target instanceof HTMLElement &&
            (
                target.matches("input, textarea, select") ||
                target.isContentEditable
            )
        ) {
            return;
        }

        event.preventDefault();

        const paused = togglePause(gameState);

        if (typeof onEscape === "function") {
            onEscape(paused);
        }
    }

    canvas.addEventListener("click", handleClick);
    window.addEventListener("keydown", handleKeyDown);

    return function detachGameInput() {
        canvas.removeEventListener("click", handleClick);
        window.removeEventListener("keydown", handleKeyDown);
    };
}
