
/**
 * Управление игровым циклом.
 *
 * Модуль не рисует игру и не меняет состояние автоматически,
 * пока ты не передашь ему функции update и render.
 */

const DEFAULT_MAX_DELTA = 0.05;

export function createGameLoop({
    update,
    render,
    isPaused = () => false,
    isRunning = () => true,
    maxDeltaTime = DEFAULT_MAX_DELTA,
    onError = (error) => console.error("[PVZ] Ошибка игрового цикла:", error),
} = {}) {
    if (typeof update !== "function") {
        throw new TypeError("Для игрового цикла нужна функция update.");
    }

    if (typeof render !== "function") {
        throw new TypeError("Для игрового цикла нужна функция render.");
    }

    let frameId = null;
    let running = false;
    let previousTime = null;

    function frame(timestamp) {
        if (!running) {
            return;
        }

        if (!isRunning()) {
            stop();
            return;
        }

        const deltaTime = previousTime === null
            ? 0
            : Math.min(
                Math.max(0, (timestamp - previousTime) / 1000),
                maxDeltaTime
            );

        previousTime = timestamp;

        try {
            if (!isPaused()) {
                update(deltaTime, timestamp);
            }

            // Рендер вызывается и на паузе, чтобы интерфейс
            // и оверлей паузы оставались видимыми.
            render(deltaTime, timestamp);
        } catch (error) {
            stop();
            onError(error);
            return;
        }

        frameId = requestAnimationFrame(frame);
    }

    function start() {
        if (running) {
            return false;
        }

        if (typeof requestAnimationFrame !== "function") {
            throw new Error(
                "Игровой цикл должен запускаться в браузере."
            );
        }

        running = true;
        previousTime = null;
        frameId = requestAnimationFrame(frame);

        return true;
    }

    function stop() {
        if (!running) {
            return false;
        }

        running = false;

        if (
            frameId !== null &&
            typeof cancelAnimationFrame === "function"
        ) {
            cancelAnimationFrame(frameId);
        }

        frameId = null;
        previousTime = null;

        return true;
    }

    function isLoopRunning() {
        return running;
    }

    return {
        start,
        stop,
        isRunning: isLoopRunning,
    };
}
