
import { PLANT_CONFIG } from "../core/config.js";
import { createPlantSun } from "../entities/sun.js";

/**
 * Обновляет производство солнц подсолнухами.
 *
 * now — время в миллисекундах.
 * Возвращает количество созданных солнц.
 */
export function updateSunProduction(
    gameState,
    now = Date.now()
) {
    if (
        !gameState ||
        gameState.paused ||
        gameState.gameOver ||
        !Array.isArray(gameState.plants) ||
        !Array.isArray(gameState.suns)
    ) {
        return 0;
    }

    let created = 0;

    for (const plant of gameState.plants) {
        if (
            !plant ||
            plant.alive === false ||
            plant.health <= 0 ||
            plant.type !== "sunflower"
        ) {
            continue;
        }

        const config = PLANT_CONFIG.sunflower;

        if (!config) {
            continue;
        }

        const interval = (config.sunInterval ?? 24) * 1000;

        if (!Number.isFinite(plant.lastSunAt)) {
            plant.lastSunAt = now;
            continue;
        }

        if (now - plant.lastSunAt < interval) {
            continue;
        }

        const sun = createPlantSun(plant, now);

        if (sun) {
            gameState.suns.push(sun);
            plant.lastSunAt = now;
            created++;
        }
    }

    return created;
}
