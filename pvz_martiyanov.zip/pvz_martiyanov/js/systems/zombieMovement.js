
import { GAME_CONFIG } from "../core/config.js";
import {
    isZombieAlive,
    moveZombie,
} from "../entities/zombies.js";

/**
 * Обновляет движение всех живых зомби.
 *
 * deltaTime — время кадра в секундах.
 * Возвращает количество зомби, достигших левого края.
 */
export function updateZombieMovement(
    gameState,
    deltaTime,
    options = {}
) {
    if (
        !gameState ||
        gameState.paused ||
        gameState.gameOver ||
        !Array.isArray(gameState.zombies)
    ) {
        return 0;
    }

    const leftBoundary = Number.isFinite(options.leftBoundary)
        ? options.leftBoundary
        : 0;

    let breached = 0;

    for (const zombie of gameState.zombies) {
        if (!isZombieAlive(zombie)) {
            continue;
        }

        moveZombie(zombie, deltaTime, options.now ?? Date.now());

        if (zombie.x <= leftBoundary) {
            zombie.x = leftBoundary;
            zombie.reachedHouse = true;
            breached++;
        }
    }

    return breached;
}

/**
 * Проверяет, достиг ли хотя бы один зомби дома.
 */
export function hasZombieReachedHouse(
    gameState,
    leftBoundary = 0
) {
    if (!Array.isArray(gameState?.zombies)) {
        return false;
    }

    return gameState.zombies.some((zombie) =>
        isZombieAlive(zombie) &&
        (
            zombie.reachedHouse === true ||
            zombie.x <= leftBoundary
        )
    );
}

/**
 * Возвращает живых зомби, достигших дома.
 */
export function getBreachedZombies(
    gameState,
    leftBoundary = 0
) {
    if (!Array.isArray(gameState?.zombies)) {
        return [];
    }

    return gameState.zombies.filter((zombie) =>
        isZombieAlive(zombie) &&
        (
            zombie.reachedHouse === true ||
            zombie.x <= leftBoundary
        )
    );
}
