
import { GAME_CONFIG } from "./core/config.js";
import { gameState } from "./core/game.js";
import {
    createMenuState,
    SCREEN,
} from "./ui/menu.js";
import { getHudData } from "./ui/hud.js";
import { isGamePaused } from "./ui/pause.js";

/**
 * Точка входа модульной версии игры.
 *
 * ВНИМАНИЕ:
 * Это пока подготовительный каркас.
 * Он не заменяет старый script.js и не запускает
 * полноценный игровой цикл.
 */

export const menuState = createMenuState(SCREEN.MENU);

/**
 * Проверяет, что базовые модули загружаются.
 */
export function validateModules() {
    const errors = [];

    if (!GAME_CONFIG || !Number.isInteger(GAME_CONFIG.COLS)) {
        errors.push("Некорректная конфигурация игрового поля.");
    }

    if (!gameState || typeof gameState !== "object") {
        errors.push("Не удалось загрузить состояние игры.");
    }

    if (typeof getHudData !== "function") {
        errors.push("Не удалось загрузить модуль HUD.");
    }

    if (typeof isGamePaused !== "function") {
        errors.push("Не удалось загрузить модуль паузы.");
    }

    return {
        valid: errors.length === 0,
        errors,
    };
}

/**
 * Возвращает сводку состояния игры для отладки.
 */
export function getDebugState() {
    return {
        screen: menuState.currentScreen,
        paused: isGamePaused(gameState),
        hud: getHudData(gameState),
        field: {
            columns: GAME_CONFIG.COLS,
            rows: GAME_CONFIG.ROWS,
            cellWidth: GAME_CONFIG.CELL_W,
            cellHeight: GAME_CONFIG.CELL_H,
        },
    };
}

/**
 * Проверяет подготовленные модули и выводит результат.
 */
export function initializeModules() {
    const result = validateModules();

    if (!result.valid) {
        console.error(
            "[PVZ] Ошибки загрузки модулей:",
            result.errors
        );

        return false;
    }

    console.info("[PVZ] Модули успешно загружены.");
    console.info("[PVZ] Конфигурация поля:", {
        columns: GAME_CONFIG.COLS,
        rows: GAME_CONFIG.ROWS,
    });

    return true;
}

/**
 * Не запускаем игру автоматически при импорте:
 * это позволит подключить модуль к интерфейсу
 * отдельно, когда интеграция будет готова.
 */
