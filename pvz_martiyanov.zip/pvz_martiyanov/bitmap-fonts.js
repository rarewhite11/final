/* Local PopCap bitmap-font renderer using the accompanying TXT glyph tables. */
(() => {
  'use strict';
  let metadataPromise = null;
  const fonts = new Map();
  function getMetadata() {
    if (!metadataPromise) metadataPromise = fetch('assets/manifests/bitmap-fonts.json').then(r => {
      if (!r.ok) throw new Error('Не удалось загрузить таблицы bitmap-шрифтов');
      return r.json();
    });
    return metadataPromise;
  }
  async function load(name) {
    if (fonts.has(name)) return fonts.get(name);
    const promise = (async () => {
      const all = await getMetadata();
      const data = all[name];
      if (!data) throw new Error(`Bitmap-шрифт ${name} не найден`);
      const image = new Image();
      await new Promise((resolve, reject) => {
        image.onload = resolve;
        image.onerror = () => reject(new Error(`Не загружен атлас ${data.atlas}`));
        image.src = data.atlas;
      });
      const glyphs = new Map();
      for (const glyph of data.glyphs) glyphs.set(glyph.char, glyph);
      return { ...data, image, glyphs };
    })();
    fonts.set(name, promise);
    try { const ready = await promise; fonts.set(name, ready); return ready; }
    catch (error) { fonts.delete(name); throw error; }
  }
  async function preload(names) { await Promise.all(names.map(load)); }
  function draw(ctx, name, text, x, y, scale = 1, align = 'left') {
    const font = fonts.get(name);
    if (!font || typeof font.then === 'function') return false;
    const chars = Array.from(String(text));
    // Do not render a partially missing word: let the UI use its normal font instead.
    if (chars.some(ch => !font.glyphs.has(ch))) return false;
    const total = chars.reduce((sum, ch) => sum + font.glyphs.get(ch).advance, 0) * scale;
    let cursor = align === 'center' ? x - total / 2 : (align === 'right' ? x - total : x);
    ctx.save();
    for (const ch of chars) {
      const glyph = font.glyphs.get(ch);
      const [sx, sy, sw, sh] = glyph.rect;
      const [ox, oy] = glyph.offset;
      if (sw > 0 && sh > 0) {
        ctx.drawImage(font.image, sx, sy, sw, sh,
          cursor + ox * scale, y + oy * scale, sw * scale, sh * scale);
      }
      cursor += glyph.advance * scale;
    }
    ctx.restore();
    return true;
  }
  window.PVZBitmapFonts = { load, preload, draw };
})();
