// Локальная авторизация PvZ на IndexedDB.
// Не требует Node.js, Python, отдельного сервера или подключения к интернету.
// Данные хранятся в профиле текущего браузера на этом компьютере.
class AuthSystem {
    constructor() {
        this.currentUser = null;
        this.dbName = 'pvz_college_local_db';
        this.dbVersion = 1;
        this.legacyKey = 'pvz_local_database_v1';
        this.sessionKey = 'pvz_current_user';
        this.resetKey = 'pvz_password_resets_v1';
        this.dbPromise = null;
        this.loadSession();
        this.ready = this.openDB().then(() => this.migrateLegacyData());
    }

    openDB() {
        if (this.dbPromise) return this.dbPromise;
        this.dbPromise = new Promise((resolve, reject) => {
            if (!('indexedDB' in window)) {
                reject(new Error('Этот браузер не поддерживает IndexedDB. Откройте игру в актуальном Chrome или Edge.'));
                return;
            }
            const request = indexedDB.open(this.dbName, this.dbVersion);
            request.onupgradeneeded = () => {
                const db = request.result;
                if (!db.objectStoreNames.contains('users')) {
                    const users = db.createObjectStore('users', { keyPath: 'id', autoIncrement: true });
                    users.createIndex('email', 'email', { unique: true });
                    users.createIndex('nicknameLower', 'nicknameLower', { unique: true });
                }
                if (!db.objectStoreNames.contains('stats')) {
                    const stats = db.createObjectStore('stats', { keyPath: 'id', autoIncrement: true });
                    stats.createIndex('userId', 'userId', { unique: true });
                    stats.createIndex('score', 'score', { unique: false });
                }
            };
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error || new Error('Не удалось открыть локальную базу данных.'));
            request.onblocked = () => reject(new Error('База данных занята другой вкладкой. Закройте другие вкладки игры и обновите страницу.'));
        });
        return this.dbPromise;
    }

    async storeRequest(storeName, mode, action) {
        await this.ready;
        const db = await this.openDB();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(storeName, mode);
            const store = tx.objectStore(storeName);
            let result;
            try { result = action(store); }
            catch (error) { reject(error); return; }
            tx.oncomplete = () => resolve(result && result.result !== undefined ? result.result : result);
            tx.onerror = () => reject(tx.error || new Error('Ошибка локальной базы данных.'));
            tx.onabort = () => reject(tx.error || new Error('Операция с базой данных отменена.'));
        });
    }

    async getAll(storeName) {
        await this.ready;
        const db = await this.openDB();
        return new Promise((resolve, reject) => {
            const tx = db.transaction(storeName, 'readonly');
            const request = tx.objectStore(storeName).getAll();
            request.onsuccess = () => resolve(request.result || []);
            request.onerror = () => reject(request.error);
        });
    }

    async migrateLegacyData() {
        // Важно: миграция выполняется до завершения this.ready, поэтому
        // здесь нельзя вызывать getAll/storeRequest, которые ожидают this.ready.
        let old;
        try { old = JSON.parse(localStorage.getItem(this.legacyKey) || 'null'); } catch { old = null; }
        if (!old || !Array.isArray(old.users) || !Array.isArray(old.stats) || old.migratedToIndexedDB) return;
        const db = await this.openDB();
        const readAll = (name) => new Promise((resolve, reject) => {
            const request = db.transaction(name, 'readonly').objectStore(name).getAll();
            request.onsuccess = () => resolve(request.result || []);
            request.onerror = () => reject(request.error);
        });
        const add = (name, value) => new Promise((resolve, reject) => {
            const tx = db.transaction(name, 'readwrite');
            tx.objectStore(name).add(value);
            tx.oncomplete = resolve;
            tx.onerror = () => reject(tx.error);
            tx.onabort = () => reject(tx.error);
        });
        const existingUsers = await readAll('users');
        if (existingUsers.length) return;
        for (const oldUser of old.users) {
            if (!oldUser || !oldUser.email || !oldUser.nickname || !oldUser.password) continue;
            const nickname = String(oldUser.nickname).trim();
            const credentials = await this.hashPassword(String(oldUser.password));
            const record = {
                email: String(oldUser.email).trim().toLowerCase(),
                nickname,
                nicknameLower: nickname.toLowerCase(),
                passwordHash: credentials.hash,
                passwordSalt: credentials.salt,
                createdAt: oldUser.createdAt || new Date().toISOString()
            };
            try { await add('users', record); }
            catch (error) { console.warn('Пропуск старой учётной записи при переносе:', error); }
        }
        const migratedUsers = await readAll('users');
        const idByEmail = new Map(migratedUsers.map(user => [user.email, user.id]));
        for (const oldStat of old.stats) {
            const oldUser = old.users.find(user => user.id === oldStat.userId);
            const userId = oldUser ? idByEmail.get(String(oldUser.email).toLowerCase()) : null;
            if (!userId) continue;
            try {
                await add('stats', {
                    userId, wave: Number(oldStat.wave) || 0, score: Number(oldStat.score) || 0,
                    kills: Number(oldStat.kills) || 0, date: oldStat.date || new Date().toISOString()
                });
            } catch (error) { console.warn('Не удалось перенести старый рекорд:', error); }
        }
        // Убираем открытые пароли из старого локального хранилища после переноса.
        old.users = old.users.map(user => {
            const safeUser = { ...user };
            delete safeUser.password;
            return safeUser;
        });
        old.migratedToIndexedDB = true;
        try { localStorage.setItem(this.legacyKey, JSON.stringify(old)); } catch {}
    }

    async hashPassword(password, saltHex = null) {
        if (!window.crypto?.subtle) throw new Error('Для безопасного хранения пароля нужен защищённый контекст браузера. Используйте localhost или актуальный Chrome/Edge.');
        const salt = saltHex ? this.hexToBytes(saltHex) : crypto.getRandomValues(new Uint8Array(16));
        const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
        const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations: 150000, hash: 'SHA-256' }, key, 256);
        return { salt: this.bytesToHex(salt), hash: this.bytesToHex(new Uint8Array(bits)) };
    }

    bytesToHex(bytes) { return Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join(''); }
    hexToBytes(hex) { return new Uint8Array((hex.match(/.{1,2}/g) || []).map(byte => parseInt(byte, 16))); }

    async register(email, nickname, password) {
        await this.ready;
        email = String(email || '').trim().toLowerCase();
        nickname = String(nickname || '').trim();
        if (!email || !nickname || !password) return { success: false, error: 'Заполните все поля!' };
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { success: false, error: 'Введите корректный email!' };
        if (nickname.length < 3 || nickname.length > 16) return { success: false, error: 'Ник должен быть от 3 до 16 символов!' };
        if (password.length < 4) return { success: false, error: 'Пароль должен быть не менее 4 символов!' };
        const users = await this.getAll('users');
        if (users.some(user => user.email === email)) return { success: false, error: 'Этот email уже зарегистрирован!' };
        if (users.some(user => user.nicknameLower === nickname.toLowerCase())) return { success: false, error: 'Этот ник уже занят!' };
        const credentials = await this.hashPassword(password);
        try {
            await this.storeRequest('users', 'readwrite', store => store.add({
                email, nickname, nicknameLower: nickname.toLowerCase(),
                passwordHash: credentials.hash, passwordSalt: credentials.salt,
                createdAt: new Date().toISOString()
            }));
            return { success: true, user: { email, nickname } };
        } catch (error) {
            return { success: false, error: error.name === 'ConstraintError' ? 'Этот email или ник уже занят!' : (error.message || 'Не удалось создать аккаунт.') };
        }
    }

    async login(identifier, password) {
        await this.ready;
        identifier = String(identifier || '').trim();
        if (!identifier || !password) return { success: false, error: 'Заполните все поля!' };
        const needle = identifier.toLowerCase();
        const users = await this.getAll('users');
        const user = users.find(item => item.email === needle || item.nicknameLower === needle);
        if (!user) return { success: false, error: 'Неверный email/ник или пароль!' };
        const credentials = await this.hashPassword(password, user.passwordSalt);
        if (credentials.hash !== user.passwordHash) return { success: false, error: 'Неверный email/ник или пароль!' };
        this.currentUser = { id: user.id, email: user.email, nickname: user.nickname };
        this.saveSession();
        return { success: true, user: this.currentUser };
    }

    async saveGameStats(wave, score, kills) {
        if (!this.currentUser) return false;
        try {
            const db = await this.openDB();
            const previous = await new Promise((resolve, reject) => {
                const request = db.transaction('stats', 'readonly').objectStore('stats').index('userId').get(this.currentUser.id);
                request.onsuccess = () => resolve(request.result || null);
                request.onerror = () => reject(request.error);
            });
            const record = {
                userId: this.currentUser.id, wave: Number(wave) || 0,
                score: Number(score) || 0, kills: Number(kills) || 0,
                date: new Date().toISOString()
            };
            if (!previous || record.score > previous.score) {
                const tx = db.transaction('stats', 'readwrite');
                const store = tx.objectStore('stats');
                if (previous) store.delete(previous.id);
                store.add(record);
                await new Promise((resolve, reject) => {
                    tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); tx.onabort = () => reject(tx.error);
                });
                console.log('НОВЫЙ РЕКОРД!');
            } else console.log('Рекорд не побит');
            if (typeof window.updateStatsPanels === 'function') setTimeout(() => window.updateStatsPanels(), 100);
            return true;
        } catch (error) {
            console.error('Ошибка сохранения статистики:', error);
            return false;
        }
    }

    async getLastGameStats() {
        if (!this.currentUser) return null;
        const stats = await this.getAll('stats');
        const stat = stats.find(item => item.userId === this.currentUser.id);
        return stat ? { wave: stat.wave, score: stat.score, kills: stat.kills, date: new Date(stat.date).toLocaleString('ru-RU') } : null;
    }

    async getTopPlayers(limit = 20) {
        const [users, stats] = await Promise.all([this.getAll('users'), this.getAll('stats')]);
        const names = new Map(users.map(user => [user.id, user.nickname]));
        return stats.map(stat => ({
            nickname: names.get(stat.userId) || 'Неизвестный', score: stat.score,
            wave: stat.wave, kills: stat.kills, date: new Date(stat.date).toLocaleDateString('ru-RU')
        })).sort((a, b) => b.score - a.score).slice(0, limit);
    }

    async requestPasswordReset(email) {
        email = String(email || '').trim().toLowerCase();
        const users = await this.getAll('users');
        if (!users.some(user => user.email === email)) return { success: false, error: 'Пользователь с таким email не найден!' };
        const code = String(crypto.getRandomValues(new Uint32Array(1))[0] % 900000 + 100000);
        let resets = {};
        try { resets = JSON.parse(localStorage.getItem(this.resetKey) || '{}'); } catch {}
        resets[email] = { code, expiresAt: Date.now() + 3600000 };
        localStorage.setItem(this.resetKey, JSON.stringify(resets));
        return { success: true, message: 'Локальный код создан. Письмо на почту не отправляется.', demoCode: code };
    }

    async resetPassword(email, code, newPassword) {
        email = String(email || '').trim().toLowerCase();
        code = String(code || '').trim();
        if (!newPassword || newPassword.length < 4) return { success: false, error: 'Пароль должен быть не менее 4 символов!' };
        let resets = {};
        try { resets = JSON.parse(localStorage.getItem(this.resetKey) || '{}'); } catch {}
        const reset = resets[email];
        if (!reset || reset.code !== code) return { success: false, error: 'Неверный код!' };
        if (Date.now() > reset.expiresAt) {
            delete resets[email]; localStorage.setItem(this.resetKey, JSON.stringify(resets));
            return { success: false, error: 'Код истёк!' };
        }
        const users = await this.getAll('users');
        const user = users.find(item => item.email === email);
        if (!user) return { success: false, error: 'Пользователь не найден!' };
        const credentials = await this.hashPassword(newPassword);
        user.passwordHash = credentials.hash;
        user.passwordSalt = credentials.salt;
        await this.storeRequest('users', 'readwrite', store => store.put(user));
        delete resets[email];
        localStorage.setItem(this.resetKey, JSON.stringify(resets));
        return { success: true, message: 'Пароль успешно изменён!' };
    }

    logout() { this.currentUser = null; localStorage.removeItem(this.sessionKey); }
    saveSession() { if (this.currentUser) localStorage.setItem(this.sessionKey, JSON.stringify(this.currentUser)); }
    loadSession() {
        try { const saved = localStorage.getItem(this.sessionKey); this.currentUser = saved ? JSON.parse(saved) : null; }
        catch { this.currentUser = null; localStorage.removeItem(this.sessionKey); }
    }
    isLoggedIn() { return this.currentUser !== null; }
}
window.authSystem = new AuthSystem();
