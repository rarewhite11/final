"""Offline integrity checks for Plants vs. Zombies College Edition.
Run: python tests/validate_project.py --repeat 100
"""
from __future__ import annotations
import argparse, json, os, re, sqlite3, subprocess, sys, time, urllib.request
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT = Path(__file__).resolve().parents[1]
REQUIRED_RIGS = [
    'PeaShooter','PeaShooterSingle','SunFlower','Wallnut','Tallnut','Jalapeno','SnowPea','Caltrop',
    'Zombie','Zombie_football','Zombie_zamboni','Zombie_polevaulter','Zombie_balloon','Zombie_dancer',
    'Zombie_backup','Zombie_gargantuar','Zombie_imp','Zombie_jackbox','Sun','Cactus','Squash'
]
REQUIRED_CLIPS = {
    'Cactus':['anim_idle','anim_rise','anim_idlehigh','anim_shooting','anim_shootinghigh','anim_lower'],
    'Tallnut':['anim_idle'], 'Jalapeno':['anim_idle','anim_explode'],
    'Squash':['anim_idle','anim_lookright','anim_jumpup','anim_jumpdown'],
    'Zombie_gargantuar':['anim_walk','anim_smash','anim_throw','anim_death'],
    'Zombie_zamboni':['anim_drive'], 'Zombie_polevaulter':['anim_run','anim_jump','anim_walk'],
    'Zombie_balloon':['anim_walk','anim_pop','anim_death'],
    'Zombie_dancer':['anim_walk','anim_armraise','anim_eat'],
    'Zombie_backup':['anim_walk','anim_armraise'], 'Zombie_jackbox':['anim_walk','anim_idle','anim_pop','anim_death'],
    'Zombie_imp':['anim_walk','anim_thrown','anim_land','anim_death']
}
REQUIRED_SOUNDS = ['plant.ogg','throw.ogg','points.ogg','frozen.ogg','jalapeno.ogg','zamboni.ogg',
                   'jack_surprise.ogg','dancer.ogg','balloon_pop.ogg','gargantuar_thump.ogg','imp.ogg','mainmusic.ogg']

def validate_once():
    script=(ROOT/'script.js').read_text(encoding='utf-8')
    engine=(ROOT/'reanim-engine.js').read_text(encoding='utf-8')
    html=(ROOT/'index.html').read_text(encoding='utf-8')
    mapping=json.loads((ROOT/'assets/reanim-image-map.json').read_text(encoding='utf-8'))
    assert 'isCellOccupiedByZombie' in script and 'aheadOrTouching' in script
    assert "z.impThrown" in script and "z.health <= z.maxHealth * 0.5" in script
    assert "z.bossAction === 'smash'" in script and "z.bossAction === 'throw'" in script
    assert "cactusForm === 'rising'" in script and "shootHigh" in script
    assert "IceTrail.png" in script and "/assets/ui/plants/tallnut.png" in html
    assert "/assets/ui/plants/jalapeno.png" in html and "musicVolume" in html and "sfxVolume" in html
    assert "Zombie_jackbox" in script and "PeaShooterSingle" in script
    for rig in REQUIRED_RIGS:
        f=ROOT/'assets'/'reanim'/f'{rig}.reanim'
        assert f.is_file(), f'missing Reanim: {rig}'
        source=f.read_text(encoding='utf-8')
        symbols=set(re.findall(r'<i>([^<]+)', source))
        track_names=set(re.findall(r'<name>([^<]+)</name>', source))
        for clip in REQUIRED_CLIPS.get(rig, []):
            assert clip in track_names, f'missing animation clip {rig}:{clip}'
        assert symbols, f'no image symbols in {rig}'
        for symbol in symbols:
            path=mapping.get(symbol)
            assert path and (ROOT/path).is_file(), f'missing texture for {rig}: {symbol} -> {path}'
        ET.fromstring('<root>'+source+'</root>')
    for icon in ['pea','sunflower','walnut','iceshooter','spikerock','tallnut','jalapeno','cactus','repeater','squash']:
        assert (ROOT/'assets/ui/plants'/f'{icon}.png').is_file(), f'missing plant icon {icon}'
    assert (ROOT/'assets/particles/IceTrail.trail').is_file() and (ROOT/'assets/particles/IceTrail.png').is_file()
    for sound in REQUIRED_SOUNDS:
        assert (ROOT/'assets'/'sounds'/sound).is_file(), f'missing sound {sound}'
    for key, path in mapping.items():
        assert (ROOT/path).is_file(), f'broken map path {key}: {path}'
    db=sqlite3.connect(ROOT/'pvz.sqlite3')
    try: assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    finally: db.close()
    return True

def http_smoke():
    port=18137
    env=os.environ.copy(); env['PVZ_PORT']=str(port)
    proc=subprocess.Popen([sys.executable,'local_server.py'],cwd=ROOT,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    try:
        deadline=time.time()+8
        while time.time()<deadline:
            try:
                with urllib.request.urlopen(f'http://127.0.0.1:{port}/index.html',timeout=1) as r:
                    assert r.status==200
                break
            except Exception: time.sleep(.15)
        urls=['assets/reanim/Cactus.reanim','assets/reanim/Zombie_gargantuar.reanim',
              'assets/reanim/Zombie_zamboni.reanim','assets/reanim-image-map.json',
              'assets/particles/IceTrail.png','assets/sounds/mainmusic.ogg','assets/ui/plants/repeater.png']
        for url in urls:
            with urllib.request.urlopen(f'http://127.0.0.1:{port}/{url}',timeout=3) as r:
                assert r.status==200, url
    finally:
        proc.terminate()
        try: proc.wait(timeout=3)
        except subprocess.TimeoutExpired: proc.kill()

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--repeat',type=int,default=1); ap.add_argument('--http',action='store_true'); args=ap.parse_args()
    for _ in range(args.repeat): validate_once()
    if args.http: http_smoke()
    print(f'PASS: {args.repeat} integrity iterations'+(' + HTTP smoke' if args.http else ''))
